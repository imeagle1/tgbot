<?php
declare(strict_types=1);

define('BOT_ROOT', __DIR__);
define('BOT_VERSION', '1.3.0');

$configFile = BOT_ROOT . '/config.php';
if (!is_file($configFile)) {
    http_response_code(500);
    exit('Bot is not installed. Open install.php');
}

$GLOBALS['BOT_CONFIG'] = require $configFile;

$tz = $GLOBALS['BOT_CONFIG']['timezone'] ?? 'Asia/Tehran';
@date_default_timezone_set($tz);

if (!defined('BOT_DEBUG')) {
    define('BOT_DEBUG', !empty($GLOBALS['BOT_CONFIG']['debug']));
}

if (BOT_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
} else {
    error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
    ini_set('display_errors', '0');
}

$logDir = BOT_ROOT . '/storage/logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0755, true);
}
ini_set('error_log', $logDir . '/php-' . date('Y-m-d') . '.log');

spl_autoload_register(static function (string $class): void {
    $file = BOT_ROOT . '/app/' . str_replace(['\\', '..'], ['/', ''], $class) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

require BOT_ROOT . '/app/Helpers.php';
