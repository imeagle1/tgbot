<?php
declare(strict_types=1);

final class PosterBot
{
    private Telegram $tg;

    public function __construct()
    {
        $this->tg = new Telegram();
    }

    public function handle(array $update): void
    {
        if (isset($update['callback_query'])) {
            $this->onCallback($update['callback_query']);
            return;
        }
        if (isset($update['message'])) {
            $this->onMessage($update['message']);
            return;
        }
        if (isset($update['my_chat_member'])) {
            $this->onMyChatMember($update['my_chat_member']);
        }
    }

    private function onMessage(array $msg): void
    {
        if (($msg['chat']['type'] ?? '') !== 'private') {
            return;
        }
        $from = $msg['from'] ?? [];
        if (!empty($from['is_bot'])) {
            return;
        }
        $userId = (int) ($from['id'] ?? 0);
        if ($userId <= 0) {
            return;
        }
        $text = (string) ($msg['text'] ?? '');
        // Deep-link from channel buttons must work for admins too.
        if (strpos($text, '/start') === 0 && strlen(trim($text)) > 6) {
            (new UserHandler($this->tg))->handle($msg);
            return;
        }
        if (Auth::isAdmin($userId)) {
            (new AdminHandler($this->tg))->handle($msg);
            return;
        }
        (new UserHandler($this->tg))->handle($msg);
    }

    private function onCallback(array $cq): void
    {
        $userId = (int) ($cq['from']['id'] ?? 0);
        $data = (string) ($cq['data'] ?? '');
        if ($userId <= 0) {
            return;
        }
        if (strpos($data, 'p:') === 0) {
            (new AdminHandler($this->tg))->handleCallback($cq);
            return;
        }
        (new UserHandler($this->tg))->handleCallback($cq);
    }

    private function onMyChatMember(array $m): void
    {
        $chat = $m['chat'] ?? [];
        $new = $m['new_chat_member'] ?? [];
        $status = (string) ($new['status'] ?? '');
        $type = (string) ($chat['type'] ?? '');
        if (!in_array($type, ['channel', 'supergroup'], true)) {
            return;
        }
        Logger::info('my_chat_member ' . ($chat['id'] ?? '') . ' ' . $status);
    }
}
