<?php
declare(strict_types=1);

final class DB
{
    /** @var PDO */
    private static $pdo;
    private static $driver = 'mysql';

    public static function init(): void
    {
        if (self::$pdo instanceof PDO) {
            return;
        }
        $cfg = Config::get('db', []);
        $driver = (string) ($cfg['driver'] ?? 'mysql');
        self::$driver = $driver;

        if ($driver === 'sqlite') {
            $path = (string) ($cfg['sqlite'] ?? (BOT_ROOT . '/storage/bot.sqlite'));
            $dir = dirname($path);
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
            self::$pdo = new PDO('sqlite:' . $path, null, null, self::options());
            self::$pdo->exec('PRAGMA foreign_keys = ON');
            self::$pdo->exec('PRAGMA journal_mode = WAL');
            self::$pdo->exec('PRAGMA busy_timeout = 5000');
        } else {
            $host = $cfg['host'] ?? 'localhost';
            $port = (int) ($cfg['port'] ?? 3306);
            $name = $cfg['name'] ?? '';
            $user = $cfg['user'] ?? '';
            $pass = $cfg['pass'] ?? '';
            $charset = $cfg['charset'] ?? 'utf8mb4';
            $dsn = "mysql:host={$host};port={$port};dbname={$name};charset={$charset}";
            self::$pdo = new PDO($dsn, (string) $user, (string) $pass, self::options());
        }
        if (self::tableExists('posts')) {
            self::migrate();
        }
    }

    private static function options(): array
    {
        return [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_TIMEOUT            => 8,
        ];
    }

    public static function pdo(): PDO
    {
        if (!self::$pdo) {
            self::init();
        }
        return self::$pdo;
    }

    public static function driver(): string
    {
        return self::$driver;
    }

    public static function isSqlite(): bool
    {
        return self::$driver === 'sqlite';
    }

    public static function exec(string $sql, array $params = []): int
    {
        $stmt = self::pdo()->prepare(self::adapt($sql));
        $stmt->execute($params);
        return $stmt->rowCount();
    }

    public static function one(string $sql, array $params = []): ?array
    {
        $stmt = self::pdo()->prepare(self::adapt($sql));
        $stmt->execute($params);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    public static function all(string $sql, array $params = []): array
    {
        $stmt = self::pdo()->prepare(self::adapt($sql));
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function col(string $sql, array $params = [])
    {
        $stmt = self::pdo()->prepare(self::adapt($sql));
        $stmt->execute($params);
        $v = $stmt->fetchColumn();
        return $v === false ? null : $v;
    }

    public static function lastId(): int
    {
        return (int) self::pdo()->lastInsertId();
    }

    public static function upsertSetting(string $key, $value): void
    {
        $json = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (self::isSqlite()) {
            self::exec('INSERT INTO settings (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v', [$key, $json]);
        } else {
            self::exec('INSERT INTO settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)', [$key, $json]);
        }
        Settings::flush();
    }

    public static function installSchema(): void
    {
        $sql = self::isSqlite() ? self::sqliteSchema() : self::mysqlSchema();
        foreach (self::splitStatements($sql) as $stmt) {
            self::pdo()->exec($stmt);
        }
    }

    private static function splitStatements(string $sql): array
    {
        $out = [];
        foreach (preg_split('/;\s*\n/', trim($sql)) as $part) {
            $part = trim($part);
            if ($part !== '') {
                $out[] = rtrim($part, ';');
            }
        }
        return $out;
    }

    private static function adapt(string $sql): string
    {
        if (!self::isSqlite()) {
            return $sql;
        }
        // no-op; sqlite-specific SQL is chosen by callers when needed
        return $sql;
    }

    private static function mysqlSchema(): string
    {
        return <<<SQL
CREATE TABLE IF NOT EXISTS admins (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL UNIQUE,
  username VARCHAR(64) DEFAULT NULL,
  role VARCHAR(16) NOT NULL DEFAULT 'admin',
  created_at INT UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS settings (
  k VARCHAR(64) PRIMARY KEY,
  v MEDIUMTEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS forced_channels (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  chat_id BIGINT NOT NULL UNIQUE,
  title VARCHAR(255) DEFAULT NULL,
  username VARCHAR(64) DEFAULT NULL,
  invite_link VARCHAR(255) DEFAULT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS caption_filters (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pattern VARCHAR(500) NOT NULL,
  type VARCHAR(16) NOT NULL DEFAULT 'plain',
  replacement VARCHAR(500) NOT NULL DEFAULT '',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at INT UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS posts (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  status VARCHAR(32) NOT NULL,
  poster_file_id VARCHAR(255) DEFAULT NULL,
  poster_unique_id VARCHAR(128) DEFAULT NULL,
  poster_type VARCHAR(32) DEFAULT 'photo',
  caption_raw TEXT,
  caption_public TEXT,
  private_chat_id BIGINT DEFAULT NULL,
  private_poster_mid BIGINT DEFAULT NULL,
  public_chat_id BIGINT DEFAULT NULL,
  public_message_id BIGINT DEFAULT NULL,
  created_by BIGINT NOT NULL,
  created_at INT UNSIGNED NOT NULL,
  published_at INT UNSIGNED DEFAULT NULL,
  source_url TEXT,
  caption_html TINYINT(1) NOT NULL DEFAULT 0,
  INDEX idx_posts_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS post_links (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  post_id INT UNSIGNED NOT NULL,
  url TEXT NOT NULL,
  label VARCHAR(255) DEFAULT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  INDEX idx_links_post (post_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS post_files (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  post_id INT UNSIGNED NOT NULL,
  file_id VARCHAR(255) NOT NULL,
  file_unique_id VARCHAR(128) DEFAULT NULL,
  file_type VARCHAR(32) NOT NULL DEFAULT 'video',
  quality VARCHAR(80) NOT NULL DEFAULT '',
  width INT DEFAULT NULL,
  height INT DEFAULT NULL,
  duration INT DEFAULT NULL,
  file_size BIGINT DEFAULT NULL,
  mime VARCHAR(80) DEFAULT NULL,
  file_name VARCHAR(255) DEFAULT NULL,
  private_chat_id BIGINT DEFAULT NULL,
  private_message_id BIGINT DEFAULT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  season INT DEFAULT NULL,
  episode INT DEFAULT NULL,
  quality_key VARCHAR(20) DEFAULT NULL,
  INDEX idx_files_post (post_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS post_link_messages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  post_id INT UNSIGNED NOT NULL,
  media_file_id VARCHAR(255) DEFAULT NULL,
  media_type VARCHAR(32) NOT NULL DEFAULT 'text',
  caption_html TEXT,
  private_chat_id BIGINT DEFAULT NULL,
  private_message_id BIGINT DEFAULT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  INDEX idx_link_msgs_post (post_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS admin_states (
  user_id BIGINT PRIMARY KEY,
  state VARCHAR(64) NOT NULL,
  post_id INT UNSIGNED DEFAULT NULL,
  data TEXT,
  updated_at INT UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS scheduled_deletes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  chat_id BIGINT NOT NULL,
  message_id BIGINT NOT NULL,
  delete_at INT UNSIGNED NOT NULL,
  INDEX idx_del_at (delete_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS membership_cache (
  user_id BIGINT NOT NULL,
  chat_id BIGINT NOT NULL,
  is_member TINYINT(1) NOT NULL,
  checked_at INT UNSIGNED NOT NULL,
  PRIMARY KEY (user_id, chat_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bot_users (
  user_id BIGINT PRIMARY KEY,
  username VARCHAR(64) DEFAULT NULL,
  first_name VARCHAR(128) DEFAULT NULL,
  last_seen INT UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;
    }

    private static function sqliteSchema(): string
    {
        return <<<SQL
CREATE TABLE IF NOT EXISTS admins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL UNIQUE,
  username TEXT DEFAULT NULL,
  role TEXT NOT NULL DEFAULT 'admin',
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS settings (
  k TEXT PRIMARY KEY,
  v TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS forced_channels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id INTEGER NOT NULL UNIQUE,
  title TEXT DEFAULT NULL,
  username TEXT DEFAULT NULL,
  invite_link TEXT DEFAULT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS caption_filters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  pattern TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'plain',
  replacement TEXT NOT NULL DEFAULT '',
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  status TEXT NOT NULL,
  poster_file_id TEXT DEFAULT NULL,
  poster_unique_id TEXT DEFAULT NULL,
  poster_type TEXT DEFAULT 'photo',
  caption_raw TEXT,
  caption_public TEXT,
  private_chat_id INTEGER DEFAULT NULL,
  private_poster_mid INTEGER DEFAULT NULL,
  public_chat_id INTEGER DEFAULT NULL,
  public_message_id INTEGER DEFAULT NULL,
  created_by INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  published_at INTEGER DEFAULT NULL,
  source_url TEXT DEFAULT NULL,
  caption_html INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_posts_status ON posts(status);
CREATE TABLE IF NOT EXISTS post_links (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL,
  url TEXT NOT NULL,
  label TEXT DEFAULT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_links_post ON post_links(post_id);
CREATE TABLE IF NOT EXISTS post_files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL,
  file_id TEXT NOT NULL,
  file_unique_id TEXT DEFAULT NULL,
  file_type TEXT NOT NULL DEFAULT 'video',
  quality TEXT NOT NULL DEFAULT '',
  width INTEGER DEFAULT NULL,
  height INTEGER DEFAULT NULL,
  duration INTEGER DEFAULT NULL,
  file_size INTEGER DEFAULT NULL,
  mime TEXT DEFAULT NULL,
  file_name TEXT DEFAULT NULL,
  private_chat_id INTEGER DEFAULT NULL,
  private_message_id INTEGER DEFAULT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  season INTEGER DEFAULT NULL,
  episode INTEGER DEFAULT NULL,
  quality_key TEXT DEFAULT NULL
);
CREATE INDEX IF NOT EXISTS idx_files_post ON post_files(post_id);
CREATE TABLE IF NOT EXISTS post_link_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL,
  media_file_id TEXT DEFAULT NULL,
  media_type TEXT NOT NULL DEFAULT 'text',
  caption_html TEXT,
  private_chat_id INTEGER DEFAULT NULL,
  private_message_id INTEGER DEFAULT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_link_msgs_post ON post_link_messages(post_id);
CREATE TABLE IF NOT EXISTS admin_states (
  user_id INTEGER PRIMARY KEY,
  state TEXT NOT NULL,
  post_id INTEGER DEFAULT NULL,
  data TEXT,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS scheduled_deletes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id INTEGER NOT NULL,
  message_id INTEGER NOT NULL,
  delete_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_del_at ON scheduled_deletes(delete_at);
CREATE TABLE IF NOT EXISTS membership_cache (
  user_id INTEGER NOT NULL,
  chat_id INTEGER NOT NULL,
  is_member INTEGER NOT NULL,
  checked_at INTEGER NOT NULL,
  PRIMARY KEY (user_id, chat_id)
);
CREATE TABLE IF NOT EXISTS bot_users (
  user_id INTEGER PRIMARY KEY,
  username TEXT DEFAULT NULL,
  first_name TEXT DEFAULT NULL,
  last_seen INTEGER NOT NULL
);
SQL;
    }

    public static function migrate(): void
    {
        if (!self::tableExists('posts') || !self::tableExists('post_files')) {
            return;
        }
        self::addColumn('posts', 'source_url', 'TEXT', 'TEXT DEFAULT NULL');
        self::addColumn('posts', 'caption_html', 'TINYINT(1) NOT NULL DEFAULT 0', 'INTEGER NOT NULL DEFAULT 0');
        self::addColumn('post_files', 'season', 'INT DEFAULT NULL', 'INTEGER DEFAULT NULL');
        self::addColumn('post_files', 'episode', 'INT DEFAULT NULL', 'INTEGER DEFAULT NULL');
        self::addColumn('post_files', 'quality_key', 'VARCHAR(20) DEFAULT NULL', 'TEXT DEFAULT NULL');
        if (!self::tableExists('post_link_messages')) {
            if (self::isSqlite()) {
                self::pdo()->exec(
                    "CREATE TABLE IF NOT EXISTS post_link_messages (
                      id INTEGER PRIMARY KEY AUTOINCREMENT,
                      post_id INTEGER NOT NULL,
                      media_file_id TEXT DEFAULT NULL,
                      media_type TEXT NOT NULL DEFAULT 'text',
                      caption_html TEXT,
                      private_chat_id INTEGER DEFAULT NULL,
                      private_message_id INTEGER DEFAULT NULL,
                      sort_order INTEGER NOT NULL DEFAULT 0
                    )"
                );
                self::pdo()->exec('CREATE INDEX IF NOT EXISTS idx_link_msgs_post ON post_link_messages(post_id)');
            } else {
                self::pdo()->exec(
                    "CREATE TABLE IF NOT EXISTS post_link_messages (
                      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                      post_id INT UNSIGNED NOT NULL,
                      media_file_id VARCHAR(255) DEFAULT NULL,
                      media_type VARCHAR(32) NOT NULL DEFAULT 'text',
                      caption_html TEXT,
                      private_chat_id BIGINT DEFAULT NULL,
                      private_message_id BIGINT DEFAULT NULL,
                      sort_order INT NOT NULL DEFAULT 0,
                      INDEX idx_link_msgs_post (post_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
                );
            }
        }
    }

    private static function tableExists(string $table): bool
    {
        try {
            if (self::isSqlite()) {
                $row = self::one("SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?", [$table]);
                return $row !== null;
            }
            $db = (string) Config::get('db.name', '');
            $row = self::one(
                'SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$db, $table]
            );
            return $row !== null;
        } catch (Throwable $e) {
            return false;
        }
    }

    private static function hasColumn(string $table, string $column): bool
    {
        try {
            if (self::isSqlite()) {
                foreach (self::all('PRAGMA table_info(' . $table . ')') as $c) {
                    if (strcasecmp((string) ($c['name'] ?? ''), $column) === 0) {
                        return true;
                    }
                }
                return false;
            }
            $db = (string) Config::get('db.name', '');
            $row = self::one(
                'SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$db, $table, $column]
            );
            return $row !== null;
        } catch (Throwable $e) {
            return false;
        }
    }

    private static function addColumn(string $table, string $column, string $mysqlDef, string $sqliteDef): void
    {
        if (self::hasColumn($table, $column)) {
            return;
        }
        $def = self::isSqlite() ? $sqliteDef : $mysqlDef;
        self::pdo()->exec('ALTER TABLE ' . $table . ' ADD COLUMN ' . $column . ' ' . $def);
    }
}
