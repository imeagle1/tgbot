<?php
declare(strict_types=1);

if (!function_exists('h')) {
    function h(?string $s): string
    {
        return htmlspecialchars((string) $s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

function utf16Slice(string $text, int $offset, int $length): string
{
    $utf16 = mb_convert_encoding($text, 'UTF-16LE', 'UTF-8');
    $slice = substr($utf16, $offset * 2, $length * 2);
    if ($slice === false || $slice === '') {
        return '';
    }
    return mb_convert_encoding($slice, 'UTF-8', 'UTF-16LE');
}

function tgText(array $msg): string
{
    if (isset($msg['text'])) {
        return (string) $msg['text'];
    }
    if (isset($msg['caption'])) {
        return (string) $msg['caption'];
    }
    return '';
}

function tgEntities(array $msg): array
{
    if (!empty($msg['entities']) && is_array($msg['entities'])) {
        return $msg['entities'];
    }
    if (!empty($msg['caption_entities']) && is_array($msg['caption_entities'])) {
        return $msg['caption_entities'];
    }
    return [];
}

function bytesToHuman($bytes): string
{
    $bytes = (float) $bytes;
    if ($bytes <= 0) {
        return '';
    }
    $units = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    while ($bytes >= 1024 && $i < 3) {
        $bytes /= 1024;
        $i++;
    }
    $fmt = $i === 0 ? '%d %s' : '%.1f %s';
    return sprintf($fmt, $bytes, $units[$i]);
}

function kb(array $rows): array
{
    return ['inline_keyboard' => $rows];
}

function btn(string $text, string $data): array
{
    return ['text' => $text, 'callback_data' => $data];
}

function urlBtn(string $text, string $url): array
{
    return ['text' => $text, 'url' => $url];
}

function replyKb(array $rows, bool $oneTime = false): array
{
    return [
        'keyboard' => $rows,
        'resize_keyboard' => true,
        'one_time_keyboard' => $oneTime,
    ];
}

function removeKb(): array
{
    return ['remove_keyboard' => true];
}

function now(): int
{
    return time();
}

function tgTextToHtml(string $text, array $entities): string
{
    if ($text === '') {
        return '';
    }
    if ($entities === []) {
        return h($text);
    }

    $utf16 = mb_convert_encoding($text, 'UTF-16LE', 'UTF-8');
    $units = (int) (strlen($utf16) / 2);
    $opens = [];
    $closes = [];

    foreach ($entities as $ent) {
        $type = (string) ($ent['type'] ?? '');
        $off = (int) ($ent['offset'] ?? 0);
        $len = (int) ($ent['length'] ?? 0);
        if ($len <= 0 || $off < 0 || $off >= $units) {
            continue;
        }
        $end = min($units, $off + $len);
        $open = '';
        $close = '';
        if ($type === 'text_link' && !empty($ent['url'])) {
            $open = '<a href="' . h((string) $ent['url']) . '">';
            $close = '</a>';
        } elseif ($type === 'url') {
            $slice = utf16Slice($text, $off, $end - $off);
            $url = LinkExtractor::normalize($slice);
            if ($url !== '' && LinkExtractor::isValid($url)) {
                $open = '<a href="' . h($url) . '">';
                $close = '</a>';
            }
        } elseif ($type === 'bold' || $type === 'strong') {
            $open = '<b>';
            $close = '</b>';
        } elseif ($type === 'italic' || $type === 'em') {
            $open = '<i>';
            $close = '</i>';
        } elseif ($type === 'underline') {
            $open = '<u>';
            $close = '</u>';
        } elseif ($type === 'strikethrough') {
            $open = '<s>';
            $close = '</s>';
        } elseif ($type === 'code') {
            $open = '<code>';
            $close = '</code>';
        } elseif ($type === 'pre') {
            $open = '<pre>';
            $close = '</pre>';
        }
        if ($open === '') {
            continue;
        }
        $opens[$off][] = $open;
        $closes[$end][] = $close;
    }

    $out = '';
    for ($i = 0; $i < $units; $i++) {
        if (!empty($closes[$i])) {
            foreach (array_reverse($closes[$i]) as $t) {
                $out .= $t;
            }
        }
        if (!empty($opens[$i])) {
            foreach ($opens[$i] as $t) {
                $out .= $t;
            }
        }
        $ch = mb_convert_encoding(substr($utf16, $i * 2, 2), 'UTF-8', 'UTF-16LE');
        $out .= h($ch);
    }
    if (!empty($closes[$units])) {
        foreach (array_reverse($closes[$units]) as $t) {
            $out .= $t;
        }
    }
    return $out;
}

