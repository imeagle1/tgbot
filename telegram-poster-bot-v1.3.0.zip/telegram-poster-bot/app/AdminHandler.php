<?php
declare(strict_types=1);

final class AdminHandler
{
    private Telegram $tg;

    public function __construct(Telegram $tg)
    {
        $this->tg = $tg;
    }

    public function handle(array $msg): void
    {
        $userId = (int) $msg['from']['id'];
        $chatId = (int) $msg['chat']['id'];
        $text = trim(tgText($msg));
        $st = Auth::state($userId);
        $state = $st['state'];

        if ($text === '/cancel' || $text === 'انصراف') {
            $this->cancel($chatId, $userId);
            return;
        }

        if ($text === '/start' || $text === '/panel' || $text === 'پنل مدیریت') {
            Auth::clearState($userId);
            $this->panel($chatId, $userId);
            return;
        }
        if ($text === '/help') {
            $this->help($chatId);
            return;
        }

        switch ($state) {
            case 'collecting_links':
                $this->onLinks($msg, $st);
                return;
            case 'collecting_files':
                $this->onFiles($msg, $st);
                return;
            case 'confirm_publish':
                $this->onConfirm($msg, $st);
                return;
            case 'setup_private':
                $this->onChannelSetup($msg, 'private');
                return;
            case 'setup_public':
                $this->onChannelSetup($msg, 'public');
                return;
            case 'add_force_channel':
                $this->onAddForceChannel($msg);
                return;
            case 'add_filter':
                $this->onAddFilter($msg);
                return;
            case 'set_footer':
                $this->onSetFooter($msg);
                return;
            case 'add_admin':
                $this->onAddAdmin($msg);
                return;
            case 'set_delete':
                $this->onSetDelete($msg);
                return;
        }

        $poster = Media::poster($msg);
        if ($poster) {
            $this->startPost($msg, $poster);
            return;
        }

        if (SiteScraper::isPageUrl($text)) {
            $this->startFromSite($msg, $text);
            return;
        }

        $this->tg->sendMessage($chatId, "برای ساخت پست جدید، <b>پوستر + کپشن</b> یا <b>لینک صفحه سایت</b> را بفرستید.\nبرای تنظیمات: /panel");
    }

    public function handleCallback(array $cq): void
    {
        $userId = (int) $cq['from']['id'];
        $data = (string) ($cq['data'] ?? '');
        $chatId = (int) ($cq['message']['chat']['id'] ?? $userId);
        $mid = (int) ($cq['message']['message_id'] ?? 0);
        $id = (string) $cq['id'];

        if (!Auth::isAdmin($userId)) {
            $this->tg->answerCallback($id, 'دسترسی ندارید', true);
            return;
        }

        $this->tg->answerCallback($id);

        if ($data === 'p:home') {
            $this->panel($chatId, $userId, $mid);
            return;
        }
        if ($data === 'p:private') {
            Auth::setState($userId, 'setup_private');
            $this->tg->sendMessage($chatId, "🔐 یک پیام از <b>کانال خصوصی آرشیو</b> را برایم فوروارد کنید، یا آیدی عددی را بفرستید (مثال: <code>-100123...</code>).\nربات باید در آن کانال ادمین باشد.\n/cancel");
            return;
        }
        if ($data === 'p:public') {
            Auth::setState($userId, 'setup_public');
            $this->tg->sendMessage($chatId, "📣 یک پیام از <b>کانال عمومی</b> را فوروارد کنید یا آیدی/-یوزرنیم را بفرستید.\nربات باید ادمین کانال با دسترسی ارسال پیام باشد.\n/cancel");
            return;
        }
        if ($data === 'p:join') {
            $this->joinPanel($chatId, $mid);
            return;
        }
        if ($data === 'p:join_add') {
            $n = (int) DB::col('SELECT COUNT(*) FROM forced_channels', []);
            if ($n >= 20) {
                $this->tg->sendMessage($chatId, 'حداکثر ۲۰ کانال جوین اجباری مجاز است.');
                return;
            }
            Auth::setState($userId, 'add_force_channel');
            $this->tg->sendMessage($chatId, "یک پیام از کانال جوین اجباری را فوروارد کنید، یا @username / آیدی را بفرستید.\nربات باید ادمین آن کانال باشد تا عضویت را چک کند.\n/cancel");
            return;
        }
        if ($data === 'p:join_toggle') {
            Settings::set('force_join_enabled', !Settings::forceJoinEnabled());
            $this->joinPanel($chatId, $mid);
            return;
        }
        if (strpos($data, 'p:join_del:') === 0) {
            $cid = (int) substr($data, strlen('p:join_del:'));
            DB::exec('DELETE FROM forced_channels WHERE id = ?', [$cid]);
            $this->joinPanel($chatId, $mid);
            return;
        }
        if ($data === 'p:filters') {
            $this->filterPanel($chatId, $mid);
            return;
        }
        if ($data === 'p:filter_add') {
            Auth::setState($userId, 'add_filter');
            $this->tg->sendMessage($chatId, "متن یا الگوی فیلتر را بفرستید.\n\nمثال‌ها:\n<code>@ChannelName</code>\n<code>regex:https?://t\\.me/\\S+</code>\n\nیا یکی از پیش‌فرض‌ها را با همین متن بفرستید:\n<code>preset:username</code> حذف یوزرنیم‌ها\n<code>preset:tmelink</code> حذف لینک تلگرام\n<code>preset:urls</code> حذف همه URLها\n/cancel");
            return;
        }
        if (strpos($data, 'p:filter_del:') === 0) {
            DB::exec('DELETE FROM caption_filters WHERE id = ?', [(int) substr($data, strlen('p:filter_del:'))]);
            $this->filterPanel($chatId, $mid);
            return;
        }
        if ($data === 'p:footer') {
            Auth::setState($userId, 'set_footer');
            $cur = Settings::footer();
            $this->tg->sendMessage($chatId, "فوتر فعلی:\n" . ($cur !== '' ? "<code>" . h($cur) . "</code>" : '— خالی —') . "\n\nمتن فوتر جدید را بفرستید.\nبرای حذف فوتر: <code>-</code>\n/cancel");
            return;
        }
        if ($data === 'p:admins') {
            $this->adminPanel($chatId, $userId, $mid);
            return;
        }
        if ($data === 'p:admin_add') {
            if (!Auth::isOwner($userId)) {
                $this->tg->sendMessage($chatId, 'فقط مالک می‌تواند ادمین اضافه کند.');
                return;
            }
            Auth::setState($userId, 'add_admin');
            $this->tg->sendMessage($chatId, "آیدی عددی ادمین را بفرستید، یا یک پیام از طرف او را فوروارد کنید.\n/cancel");
            return;
        }
        if (strpos($data, 'p:admin_del:') === 0) {
            if (!Auth::isOwner($userId)) {
                return;
            }
            Auth::removeAdmin((int) substr($data, strlen('p:admin_del:')));
            $this->adminPanel($chatId, $userId, $mid);
            return;
        }
        if ($data === 'p:settings') {
            $this->settingsPanel($chatId, $mid);
            return;
        }
        if ($data === 'p:set_delete') {
            Auth::setState($userId, 'set_delete');
            $this->tg->sendMessage($chatId, 'زمان حذف محتوا برای کاربر را به ثانیه بفرستید (۵ تا ۳۰۰). فعلی: ' . Settings::deleteAfter() . "\n/cancel");
            return;
        }
        if ($data === 'p:stats') {
            $this->stats($chatId, $mid);
            return;
        }
        if ($data === 'p:publish_yes') {
            $st = Auth::state($userId);
            $pid = (int) ($st['post_id'] ?? 0);
            if ($pid > 0) {
                $this->doPublish($chatId, $userId, $pid);
            }
            return;
        }
        if ($data === 'p:publish_no') {
            $this->cancel($chatId, $userId);
            return;
        }
    }

    private function startPost(array $msg, array $poster): void
    {
        $userId = (int) $msg['from']['id'];
        $chatId = (int) $msg['chat']['id'];
        if (!Settings::privateChannelId() || !Settings::publicChannelId()) {
            $this->tg->sendMessage($chatId, "اول کانال خصوصی و عمومی را از /panel تنظیم کنید.");
            $this->panel($chatId, $userId);
            return;
        }
        $caption = (string) ($msg['caption'] ?? '');
        $fwd = PostService::archiveForward($this->tg, $msg);
        $privMid = !empty($fwd['ok']) ? (int) $fwd['result']['message_id'] : null;
        $privChat = Settings::privateChannelId();
        $postId = PostService::createDraft($userId, $poster, $caption, $privChat, $privMid);
        Auth::setState($userId, 'collecting_links', $postId, []);

        $this->tg->sendMessage($chatId,
            "✅ پوستر ذخیره شد" . ($privMid ? " و به کانال خصوصی فوروارد شد." : ".") . "\n\n"
            . "🔗 حالا <b>پست لینک‌ها</b> را بفرستید.\n"
            . "می‌توانید همان پست عکس+کپشن با هایپرلینک را بفرستید؛ عیناً (با فیلتر کپشن اگر فعال باشد) به کانال خصوصی می‌رود و بعد همان برای کاربر ارسال می‌شود.\n"
            . "یا لینک صفحه سایت را بفرستید تا کیفیت‌ها استخراج شود.\n"
            . "چند پیام پشت‌سرهم هم قبول است.\n\n"
            . "اگر لینکی نیست روی «بدون لینک» بزنید.",
            ['reply_markup' => $this->collectKb('links')]
        );
    }

    private function onLinks(array $msg, array $st): void
    {
        $chatId = (int) $msg['chat']['id'];
        $userId = (int) $msg['from']['id'];
        $postId = (int) $st['post_id'];
        $text = trim(tgText($msg));

        $video = Media::video($msg);
        if ($video) {
            $this->ingestFile($msg, $postId, $video);
            Auth::setState($userId, 'collecting_files', $postId);
            $c = PostService::counts($postId);
            $this->tg->sendMessage($chatId, $this->fileStatus($postId, $c), ['reply_markup' => $this->collectKb('files')]);
            return;
        }

        if (in_array($text, ['/skip', 'بدون لینک', 'بدون لینک‌ها', '/done', 'ادامه'], true)) {
            Auth::setState($userId, 'collecting_files', $postId);
            $this->tg->sendMessage($chatId,
                "🎞 حالا <b>فایل‌ها / ویدیوها</b> را بفرستید.\nکیفیت از اسم فایل، کپشن و ابعاد ویدیو تشخیص داده می‌شود (مثل 1080p x265).\nهر فایل به کانال خصوصی فوروارد و file_id ذخیره می‌شود.\n\nوقتی تمام شد «انتشار پست» را بزنید.",
                ['reply_markup' => $this->collectKb('files')]
            );
            return;
        }

        if (SiteScraper::isPageUrl($text) && !Media::poster($msg)) {
            $this->ingestSiteUrl($chatId, $userId, $postId, $text);
            return;
        }

        $hasMedia = Media::poster($msg) !== null;
        $extracted = LinkExtractor::extract($msg);
        if (!$hasMedia && $extracted === [] && trim(tgText($msg)) === '') {
            $this->tg->sendMessage($chatId, "پست عکس+کپشن، لینک صفحه سایت، یا پیام حاوی لینک بفرستید؛ یا «بدون لینک» را بزنید.");
            return;
        }
        if (!$hasMedia && $extracted === []) {
            $this->tg->sendMessage($chatId, "لینکی در این پیام پیدا نشد. پست عکس+کپشن با هایپرلینک، لینک سایت، یا «بدون لینک» را بفرستید.");
            return;
        }

        $saved = PostService::saveLinkMessageFromUpdate($this->tg, $postId, $msg);
        if (empty($saved['ok'])) {
            $this->tg->sendMessage($chatId, '❌ ارسال به کانال خصوصی ناموفق بود: ' . h((string) ($saved['error'] ?? '')));
            return;
        }
        $total = PostService::counts($postId)['links'];
        $this->tg->sendMessage(
            $chatId,
            "✅ پست لینک در کانال خصوصی ذخیره شد (جمع: {$total}).\nهمین پست بعداً برای کاربر کپی می‌شود.\n\nپست بعدی را بفرستید یا «ادامه» را بزنید.",
            ['reply_markup' => $this->collectKb('links')]
        );
    }

    private function onFiles(array $msg, array $st): void
    {
        $chatId = (int) $msg['chat']['id'];
        $userId = (int) $msg['from']['id'];
        $postId = (int) $st['post_id'];
        $text = trim(tgText($msg));

        if (in_array($text, ['/done', 'انتشار پست', 'انتشار', 'تموم'], true)) {
            $this->askPublish($chatId, $userId, $postId);
            return;
        }
        if (in_array($text, ['/skip', 'بدون فایل', 'بدون فایل‌ها'], true)) {
            $this->askPublish($chatId, $userId, $postId);
            return;
        }

        $video = Media::video($msg);
        if (!$video) {
            $this->tg->sendMessage($chatId, "ویدیو/فایل ویدیویی بفرستید، یا «انتشار پست» را بزنید.");
            return;
        }
        $this->ingestFile($msg, $postId, $video);
        $c = PostService::counts($postId);
        $this->tg->sendMessage($chatId, $this->fileStatus($postId, $c), ['reply_markup' => $this->collectKb('files')]);
    }

    private function ingestFile(array $msg, int $postId, array $video): void
    {
        $caption = (string) ($msg['caption'] ?? '');
        $hay = $caption . ' ' . ($video['file_name'] ?? '');
        $quality = QualityDetector::detect($video, $hay);
        $parsed = SeriesParser::parse((string) ($video['file_name'] ?? ''), $caption);
        $qkey = QualityDetector::resolutionKey($video, $quality, $hay);
        $fwd = PostService::archiveForward($this->tg, $msg);
        $privMid = !empty($fwd['ok']) ? (int) $fwd['result']['message_id'] : null;
        $privChat = Settings::privateChannelId();
        PostService::addFile($postId, $video, $quality, $privChat, $privMid, $parsed['season'], $parsed['episode'], $qkey);
    }

    private function fileStatus(int $postId, array $c): string
    {
        $lines = "✅ فایل ذخیره شد و به کانال خصوصی فوروارد شد.\n\n🎞 فایل‌های این پست:";
        foreach (PostService::files($postId) as $i => $f) {
            $size = bytesToHuman($f['file_size'] ?? 0);
            $extra = '';
            $season = (int) ($f['season'] ?? 0);
            $episode = (int) ($f['episode'] ?? 0);
            if ($season > 0 || $episode > 0) {
                $extra = ' · ' . SeriesParser::seasonLabel($season > 0 ? $season : 1);
                if ($episode > 0) {
                    $extra .= ' قسمت ' . $episode;
                }
            }
            $lines .= "\n" . ($i + 1) . '. <b>' . h((string) $f['quality']) . '</b>' . $extra . ($size ? " ({$size})" : '');
        }
        $lines .= "\n\nلینک‌ها: {$c['links']} | فایل‌ها: {$c['files']}\nفایل بعدی را بفرستید یا «انتشار پست» را بزنید.";
        return $lines;
    }

    private function askPublish(int $chatId, int $userId, int $postId): void
    {
        $c = PostService::counts($postId);
        Auth::setState($userId, 'confirm_publish', $postId);
        $post = PostService::get($postId);
        $cap = (string) ($post['caption_raw'] ?? '');
        $preview = CaptionFilter::forPhoto($cap, !empty($post['caption_html']));
        $this->tg->sendMessage($chatId,
            "🚀 <b>آماده انتشار</b>\nلینک‌ها: {$c['links']}\nفایل‌ها: {$c['files']}\n\n"
            . "دکمه‌ها: " . ($c['links'] ? 'لینک‌ها ' : '') . ($c['files'] ? 'فایل‌ها' : ($c['links'] ? '' : 'هیچ')) . "\n\n"
            . "پیش‌نمایش کپشن:\n" . ($preview !== '' ? (!empty($post['caption_html']) ? $preview : h($preview)) : '—') . "\n\nمنتشر شود؟",
            ['reply_markup' => kb([[btn('✅ انتشار', 'p:publish_yes'), btn('❌ انصراف', 'p:publish_no')]])]
        );
    }

    private function onConfirm(array $msg, array $st): void
    {
        $text = trim(tgText($msg));
        $chatId = (int) $msg['chat']['id'];
        $userId = (int) $msg['from']['id'];
        if (in_array($text, ['بله', 'انتشار', 'انتشار پست', '/done', 'ok', 'OK'], true)) {
            $this->doPublish($chatId, $userId, (int) $st['post_id']);
            return;
        }
        $this->tg->sendMessage($chatId, 'از دکمه‌های زیر پیام قبلی استفاده کنید یا /cancel');
    }

    private function doPublish(int $chatId, int $userId, int $postId): void
    {
        $res = PostService::publish($this->tg, $postId);
        Auth::clearState($userId);
        if (empty($res['ok'])) {
            $this->tg->sendMessage($chatId, '❌ انتشار ناموفق: ' . h((string) ($res['error'] ?? '')), ['reply_markup' => removeKb()]);
            return;
        }
        $this->tg->sendMessage($chatId, "✅ پست در کانال عمومی منتشر شد.\nشنا��ه پست: <code>{$postId}</code>", ['reply_markup' => removeKb()]);
    }

    private function cancel(int $chatId, int $userId): void
    {
        $st = Auth::state($userId);
        if (!empty($st['post_id']) && in_array($st['state'], ['collecting_links', 'collecting_files', 'confirm_publish'], true)) {
            DB::exec("UPDATE posts SET status = 'cancelled' WHERE id = ? AND status != 'published'", [(int) $st['post_id']]);
        }
        Auth::clearState($userId);
        $this->tg->sendMessage($chatId, 'لغو شد.', ['reply_markup' => removeKb()]);
        $this->panel($chatId, $userId);
    }

    private function collectKb(string $mode): array
    {
        if ($mode === 'links') {
            return replyKb([[['text' => 'بدون لینک'], ['text' => 'ادامه']], [['text' => 'انصراف']]]);
        }
        return replyKb([[['text' => 'انتشار پست'], ['text' => 'بدون فایل']], [['text' => 'انصراف']]]);
    }

    private function panel(int $chatId, int $userId, int $editMid = 0): void
    {
        $priv = Settings::privateChannelId();
        $pub  = Settings::publicChannelId();
        $fc   = (int) DB::col('SELECT COUNT(*) FROM forced_channels WHERE is_active = 1', []);
        $text = "⚙️ <b>پنل مدیریت</b>  <code>v" . BOT_VERSION . "</code>\n\n"
            . "🔐 کانال خصوصی: " . ($priv ? '✅' : '❌') . "\n"
            . "📣 کانال عمومی: " . ($pub ? '✅' : '❌') . "\n"
            . "🔒 جوین اجباری: " . (Settings::forceJoinEnabled() ? "✅ {$fc} کانال" : 'خاموش') . "\n"
            . "⏱ حذف محتوا: " . Settings::deleteAfter() . " ثانیه\n"
            . "📝 فوتر: " . (Settings::footer() !== '' ? '✅' : '—') . "\n\n"
            . "برای پست جدید، پوستر + کپشن یا لینک صفحه سایت را همین‌جا بفرستید.";
        $markup = kb([
            [btn('🔐 کانال خصوصی', 'p:private'), btn('📣 کانال عمومی', 'p:public')],
            [btn('🔒 جوین اجباری', 'p:join'), btn('✂️ فیلتر کپشن', 'p:filters')],
            [btn('🧩 فوتر', 'p:footer'), btn('👥 ادمین‌ها', 'p:admins')],
            [btn('⚙️ تنظیمات', 'p:settings'), btn('📊 آمار', 'p:stats')],
        ]);
        if ($editMid > 0) {
            $this->tg->editMessageText($chatId, $editMid, $text, ['reply_markup' => $markup]);
        } else {
            $this->tg->sendMessage($chatId, $text, ['reply_markup' => $markup]);
        }
    }

    private function joinPanel(int $chatId, int $mid = 0): void
    {
        $chs = DB::all('SELECT * FROM forced_channels ORDER BY sort_order ASC, id ASC');
        $text = "🔒 <b>جوین اجباری</b>\nوضعیت: " . (Settings::forceJoinEnabled() ? 'روشن' : 'خاموش') . "\nحداکثر ۲۰ کانال.\n\n";
        $rows = [];
        if ($chs === []) {
            $text .= 'هنوز کانالی اضافه نشده.';
        }
        foreach ($chs as $ch) {
            $title = $ch['title'] ?: ($ch['username'] ? '@' . $ch['username'] : $ch['chat_id']);
            $text .= "• " . h((string) $title) . "\n";
            $rows[] = [btn('🗑 ' . mb_substr((string) $title, 0, 28), 'p:join_del:' . $ch['id'])];
        }
        $rows[] = [btn('➕ افزودن کانال', 'p:join_add')];
        $rows[] = [btn(Settings::forceJoinEnabled() ? '⏸ خاموش کردن' : '▶️ روشن کردن', 'p:join_toggle')];
        $rows[] = [btn('⬅️ بازگشت', 'p:home')];
        $markup = kb($rows);
        if ($mid > 0) {
            $this->tg->editMessageText($chatId, $mid, $text, ['reply_markup' => $markup]);
        } else {
            $this->tg->sendMessage($chatId, $text, ['reply_markup' => $markup]);
        }
    }

    private function filterPanel(int $chatId, int $mid = 0): void
    {
        $fs = DB::all('SELECT * FROM caption_filters ORDER BY id ASC');
        $text = "✂️ <b>فیلتر کپشن</b>\nاین الگوها قبل از انتشار از متن پوستر حذف/جایگزین می‌شوند. فوتر بعد از فیلتر اضافه می‌شود.\n\n";
        $rows = [];
        if ($fs === []) {
            $text .= 'فیلتری نیست.';
        }
        foreach ($fs as $f) {
            $text .= "#" . $f['id'] . " [" . h((string) $f['type']) . "] <code>" . h((string) $f['pattern']) . "</code>\n";
            $rows[] = [btn('🗑 #' . $f['id'], 'p:filter_del:' . $f['id'])];
        }
        $rows[] = [btn('➕ فیلتر جدید', 'p:filter_add')];
        $rows[] = [btn('⬅️ بازگشت', 'p:home')];
        $markup = kb($rows);
        if ($mid > 0) {
            $this->tg->editMessageText($chatId, $mid, $text, ['reply_markup' => $markup]);
        } else {
            $this->tg->sendMessage($chatId, $text, ['reply_markup' => $markup]);
        }
    }

    private function adminPanel(int $chatId, int $userId, int $mid = 0): void
    {
        $list = Auth::listAdmins();
        $text = "👥 <b>ادمین‌ها</b>\nمالک فایل کانفیگ هم همیشه ادمین است.\n\n";
        $rows = [];
        $ownerCfg = (int) Config::get('owner_id', 0);
        $text .= "• مالک کانفیگ: <code>{$ownerCfg}</code>\n";
        foreach ($list as $a) {
            $text .= "• <code>{$a['user_id']}</code> @" . h((string) ($a['username'] ?? '')) . " [" . $a['role'] . "]\n";
            if ($a['role'] !== 'owner' && Auth::isOwner($userId)) {
                $rows[] = [btn('🗑 ' . $a['user_id'], 'p:admin_del:' . $a['user_id'])];
            }
        }
        if (Auth::isOwner($userId)) {
            $rows[] = [btn('➕ افزودن ادمین', 'p:admin_add')];
        }
        $rows[] = [btn('⬅️ بازگشت', 'p:home')];
        $markup = kb($rows);
        if ($mid > 0) {
            $this->tg->editMessageText($chatId, $mid, $text, ['reply_markup' => $markup]);
        } else {
            $this->tg->sendMessage($chatId, $text, ['reply_markup' => $markup]);
        }
    }

    private function settingsPanel(int $chatId, int $mid = 0): void
    {
        $text = "⚙️ <b>تنظیمات</b>\n⏱ حذف پیام کاربر: " . Settings::deleteAfter() . " ثانیه\n";
        $markup = kb([
            [btn('⏱ زمان حذف', 'p:set_delete')],
            [btn('⬅️ بازگشت', 'p:home')],
        ]);
        if ($mid > 0) {
            $this->tg->editMessageText($chatId, $mid, $text, ['reply_markup' => $markup]);
        } else {
            $this->tg->sendMessage($chatId, $text, ['reply_markup' => $markup]);
        }
    }

    private function stats(int $chatId, int $mid = 0): void
    {
        $posts = (int) DB::col("SELECT COUNT(*) FROM posts WHERE status = 'published'", []);
        $files = (int) DB::col('SELECT COUNT(*) FROM post_files', []);
        $users = (int) DB::col('SELECT COUNT(*) FROM bot_users', []);
        $text = "📊 <b>آمار</b>\nپست‌های منتشرشده: {$posts}\nفایل‌ها: {$files}\nکاربران ربات: {$users}";
        $markup = kb([[btn('⬅️ بازگشت', 'p:home')]]);
        if ($mid > 0) {
            $this->tg->editMessageText($chatId, $mid, $text, ['reply_markup' => $markup]);
        } else {
            $this->tg->sendMessage($chatId, $text, ['reply_markup' => $markup]);
        }
    }

    private function onChannelSetup(array $msg, string $which): void
    {
        $chatId = (int) $msg['chat']['id'];
        $userId = (int) $msg['from']['id'];
        $target = $this->resolveChannel($msg);
        if (!$target) {
            $this->tg->sendMessage($chatId, 'کانال تشخیص داده نشد. پیام کانال را فوروارد کنید یا آیدی بفرستید.');
            return;
        }
        $info = $this->tg->getChat($target);
        if (empty($info['ok'])) {
            $this->tg->sendMessage($chatId, 'ربات به این کانال دسترسی ندارد. اول ربات را ادمین کنید.\n' . h((string) ($info['description'] ?? '')));
            return;
        }
        $cid = (int) $info['result']['id'];
        $title = (string) ($info['result']['title'] ?? $cid);
        if ($which === 'private') {
            Settings::set('private_channel_id', $cid);
            Settings::set('private_channel_title', $title);
        } else {
            Settings::set('public_channel_id', $cid);
            Settings::set('public_channel_title', $title);
        }
        Auth::clearState($userId);
        $this->tg->sendMessage($chatId, "✅ کانال " . ($which === 'private' ? 'خصوصی' : 'عمومی') . " تنظیم شد:\n" . h($title) . "\n<code>{$cid}</code>");
        $this->panel($chatId, $userId);
    }

    private function onAddForceChannel(array $msg): void
    {
        $chatId = (int) $msg['chat']['id'];
        $userId = (int) $msg['from']['id'];
        $target = $this->resolveChannel($msg);
        if (!$target) {
            $this->tg->sendMessage($chatId, 'کانال تشخیص داده نشد.');
            return;
        }
        $info = $this->tg->getChat($target);
        if (empty($info['ok'])) {
            $this->tg->sendMessage($chatId, 'ربات باید ادمین این کانال باشد.');
            return;
        }
        $r = $info['result'];
        $cid = (int) $r['id'];
        $title = (string) ($r['title'] ?? '');
        $username = (string) ($r['username'] ?? '');
        $link = (string) ($r['invite_link'] ?? '');
        if ($link === '' && $username === '') {
            $inv = $this->tg->createChatInviteLink($cid);
            if (!empty($inv['ok'])) {
                $link = (string) ($inv['result']['invite_link'] ?? '');
            }
        }
        if ($link === '' && $username !== '') {
            $link = 'https://t.me/' . ltrim($username, '@');
        }
        $exists = DB::one('SELECT id FROM forced_channels WHERE chat_id = ?', [$cid]);
        if ($exists) {
            DB::exec('UPDATE forced_channels SET title=?, username=?, invite_link=?, is_active=1 WHERE chat_id=?', [$title, $username, $link, $cid]);
        } else {
            $n = (int) DB::col('SELECT COUNT(*) FROM forced_channels', []);
            if ($n >= 20) {
                $this->tg->sendMessage($chatId, 'حداکثر ۲۰ کانال.');
                Auth::clearState($userId);
                return;
            }
            DB::exec(
                'INSERT INTO forced_channels (chat_id, title, username, invite_link, is_active, sort_order) VALUES (?,?,?,?,1,?)',
                [$cid, $title, $username, $link, $n]
            );
        }
        Auth::clearState($userId);
        $this->tg->sendMessage($chatId, '✅ کانال جوین اجباری اضافه شد: ' . h($title));
        $this->joinPanel($chatId);
    }

    private function onAddFilter(array $msg): void
    {
        $chatId = (int) $msg['chat']['id'];
        $userId = (int) $msg['from']['id'];
        $text = trim(tgText($msg));
        if ($text === '') {
            $this->tg->sendMessage($chatId, 'متن فیلتر را بفرستید.');
            return;
        }
        $type = 'plain';
        $pattern = $text;
        if (stripos($text, 'preset:username') === 0) {
            $type = 'username';
            $pattern = '@username';
        } elseif (stripos($text, 'preset:tmelink') === 0) {
            $type = 'tmelink';
            $pattern = 't.me';
        } elseif (stripos($text, 'preset:urls') === 0) {
            $type = 'urls';
            $pattern = 'urls';
        } elseif (stripos($text, 'regex:') === 0) {
            $type = 'regex';
            $pattern = substr($text, 6);
            if (@preg_match('/' . $pattern . '/u', '') === false) {
                $this->tg->sendMessage($chatId, 'regex نامعتبر است.');
                return;
            }
        }
        DB::exec(
            'INSERT INTO caption_filters (pattern, type, replacement, is_active, created_at) VALUES (?,?,?,?,?)',
            [$pattern, $type, '', 1, time()]
        );
        Auth::clearState($userId);
        $this->tg->sendMessage($chatId, '✅ فیلتر اضافه شد.');
        $this->filterPanel($chatId);
    }

    private function onSetFooter(array $msg): void
    {
        $chatId = (int) $msg['chat']['id'];
        $userId = (int) $msg['from']['id'];
        $text = trim(tgText($msg));
        if ($text === '-' || $text === 'حذف') {
            $text = '';
        }
        Settings::set('footer', $text);
        Auth::clearState($userId);
        $this->tg->sendMessage($chatId, $text === '' ? 'فوتر حذف شد.' : "✅ فوتر ذخیره شد:\n" . $text);
        $this->panel($chatId, $userId);
    }

    private function onAddAdmin(array $msg): void
    {
        $chatId = (int) $msg['chat']['id'];
        $userId = (int) $msg['from']['id'];
        $newId = null;
        $username = null;
        if (!empty($msg['forward_from']['id'])) {
            $newId = (int) $msg['forward_from']['id'];
            $username = $msg['forward_from']['username'] ?? null;
        } elseif (!empty($msg['forward_origin']['sender_user']['id'])) {
            $newId = (int) $msg['forward_origin']['sender_user']['id'];
            $username = $msg['forward_origin']['sender_user']['username'] ?? null;
        } elseif (preg_match('/^-?\d{5,}$/', trim(tgText($msg)))) {
            $newId = (int) trim(tgText($msg));
        }
        if (!$newId) {
            $this->tg->sendMessage($chatId, 'آیدی معتبر نیست. حریم‌خصوصی فوروارد ممکن است آیدی را مخفی کند؛ آیدی عددی را بفرستید.');
            return;
        }
        Auth::addAdmin($newId, $username, 'admin');
        Auth::clearState($userId);
        $this->tg->sendMessage($chatId, "✅ ادمین اضافه شد: <code>{$newId}</code>");
        $this->adminPanel($chatId, $userId);
    }

    private function onSetDelete(array $msg): void
    {
        $chatId = (int) $msg['chat']['id'];
        $userId = (int) $msg['from']['id'];
        $n = (int) trim(tgText($msg));
        if ($n < 5 || $n > 300) {
            $this->tg->sendMessage($chatId, 'عدد بین ۵ و ۳۰۰ بفرستید.');
            return;
        }
        Settings::set('delete_after', $n);
        Auth::clearState($userId);
        $this->tg->sendMessage($chatId, "✅ زمان حذف: {$n} ثانیه");
        $this->panel($chatId, $userId);
    }

    private function resolveChannel(array $msg)
    {
        $meta = Media::forwardedChannelMeta($msg);
        if ($meta) {
            return $meta['id'];
        }
        $text = trim(tgText($msg));
        if ($text === '') {
            return null;
        }
        if (preg_match('/^-100\d+$/', $text) || preg_match('/^-?\d{6,}$/', $text)) {
            return (int) $text;
        }
        if (preg_match('/^@?[A-Za-z0-9_]{4,32}$/', $text)) {
            return '@' . ltrim($text, '@');
        }
        if (preg_match('~t\.me/([A-Za-z0-9_]+)~', $text, $m)) {
            return '@' . $m[1];
        }
        return null;
    }

    private function help(int $chatId): void
    {
        $this->tg->sendMessage($chatId,
            "📖 <b>راهنمای ادمین</b>\n\n"
            . "۱) پوستر + کپشن را بفرستید، یا لینک صفحه سایت\n"
            . "۲) پست لینک‌ها (عکس+کپشن با هایپرلینک) — عیناً برای کاربر کپی می‌شود\n"
            . "۳) ویدیوها/فایل‌ها — برای سریال، فصل و کیفیت گروه‌بندی می‌شود\n"
            . "۴) انتشار در کانال عمومی با دکمه‌های هوشمند\n\n"
            . "کاربر روی لینک‌ها/فایل‌ها می‌زند، جوین اجباری چک می‌شود، محتوا در ربات ارسال و بعد از چند ثانیه حذف می‌شود.\n"
            . "ویدیو دوباره آپلود نمی‌شود؛ از file_id / کپی پیام کانال خصوصی استفاده می‌شود.\n\n"
            . "/panel تنظیمات"
        );
    }

    private function startFromSite(array $msg, string $url): void
    {
        $userId = (int) $msg['from']['id'];
        $chatId = (int) $msg['chat']['id'];
        if (!Settings::privateChannelId() || !Settings::publicChannelId()) {
            $this->tg->sendMessage($chatId, "اول کانال خصوصی و عمومی را از /panel تنظیم کنید.");
            $this->panel($chatId, $userId);
            return;
        }
        $this->tg->sendMessage($chatId, '⏳ در حال استخراج اطلاعات از سایت...');
        $movie = SiteScraper::scrape($url);
        if (!$movie) {
            $this->tg->sendMessage($chatId, '❌ خطا در استخراج اطلاعات. لینک را بررسی کنید یا پوستر را دستی بفرستید.');
            return;
        }
        $priv = Settings::privateChannelId();
        $publicCaption = SiteScraper::publicCaption($movie);
        $posterUrl = (string) ($movie['poster'] ?? '');
        $poster = null;
        $privMid = null;
        if ($posterUrl !== '') {
            $sent = $this->tg->sendPhoto((int) $priv, $posterUrl, CaptionFilter::forPhoto($publicCaption, true), ['parse_mode' => 'HTML']);
            if (!empty($sent['ok'])) {
                $poster = PostService::photoFromResult($sent);
                $privMid = (int) $sent['result']['message_id'];
            }
        }
        if (!$poster) {
            $this->tg->sendMessage($chatId, '❌ پوستر از سایت دریافت نشد. پوستر را دستی بفرستید و بعد لینک صفحه را در مرحله لینک‌ها ارسال کنید.');
            return;
        }
        $postId = PostService::createDraft($userId, $poster, $publicCaption, $priv, $privMid, true, $url);
        if (SiteScraper::hasLinks($movie)) {
            $linkSaved = PostService::saveScrapedLinkPost($this->tg, $postId, $movie, (string) $poster['file_id']);
            if (empty($linkSaved['ok'])) {
                $this->tg->sendMessage($chatId, '⚠️ اطلاعات فیلم ذخیره شد ولی پست لینک ساخته نشد: ' . h((string) ($linkSaved['error'] ?? '')));
            }
        }
        Auth::setState($userId, 'collecting_files', $postId);
        $c = PostService::counts($postId);
        $this->tg->sendMessage(
            $chatId,
            "✅ اطلاعات سایت استخراج شد.\nلینک‌ها: {$c['links']}\n\n🎞 حالا <b>فایل‌ها / ویدیوها</b> را بفرستید یا «انتشار پست» را بزنید.",
            ['reply_markup' => $this->collectKb('files')]
        );
    }

    private function ingestSiteUrl(int $chatId, int $userId, int $postId, string $url): void
    {
        $this->tg->sendMessage($chatId, '⏳ در حال استخراج لینک‌ها از سایت...');
        $movie = SiteScraper::scrape($url);
        if (!$movie) {
            $this->tg->sendMessage($chatId, '❌ خطا در استخراج. لینک را بررسی کنید یا پست عکس+کپشن لینک‌ها را دستی بفرستید.');
            return;
        }
        $post = PostService::get($postId);
        $posterFileId = (string) ($post['poster_file_id'] ?? '');
        $summary = SiteScraper::qualitySummary($movie);
        if ($summary !== '') {
            PostService::appendCaption($postId, $summary, true);
        }
        PostService::setSourceUrl($postId, $url);
        if (SiteScraper::hasLinks($movie)) {
            $saved = PostService::saveScrapedLinkPost($this->tg, $postId, $movie, $posterFileId !== '' ? $posterFileId : null);
            if (empty($saved['ok'])) {
                $this->tg->sendMessage($chatId, '❌ ذخیره پست لینک ناموفق: ' . h((string) ($saved['error'] ?? '')));
                return;
            }
        }
        $total = PostService::counts($postId)['links'];
        $this->tg->sendMessage(
            $chatId,
            "✅ لینک‌های سایت ذخیره شد (جمع: {$total}).\nکیفیت‌ها به کپشن پست عمومی اضافه شد.\n\nپست بعدی را بفرستید یا «ادامه» را بزنید.",
            ['reply_markup' => $this->collectKb('links')]
        );
    }
}
