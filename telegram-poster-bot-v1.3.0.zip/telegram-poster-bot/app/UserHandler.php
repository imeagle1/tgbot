<?php
declare(strict_types=1);

final class UserHandler
{
    private Telegram $tg;

    public function __construct(Telegram $tg)
    {
        $this->tg = $tg;
    }

    public function handle(array $msg): void
    {
        $userId = (int) $msg['from']['id'];
        $chatId = (int) $msg['chat']['id'];
        $this->touchUser($msg['from']);

        $text = trim((string) ($msg['text'] ?? ''));
        if (strpos($text, '/start') === 0) {
            $payload = trim(substr($text, 6));
            $payload = ltrim($payload);
            $this->start($chatId, $userId, $payload);
            return;
        }

        $this->tg->sendMessage($chatId, "برای دریافت فایل و لینک، از دکمه‌های زیر پست داخل کانال استفاده کنید.");
    }

    public function handleCallback(array $cq): void
    {
        $userId = (int) $cq['from']['id'];
        $data = (string) ($cq['data'] ?? '');
        $chatId = (int) ($cq['message']['chat']['id'] ?? $userId);
        $cbId = (string) $cq['id'];
        $this->touchUser($cq['from']);

        if (strpos($data, 'j:') === 0) {
            $payload = substr($data, 2);
            $this->tg->answerCallback($cbId, 'در حال بررسی عضویت...');
            $this->deliver($chatId, $userId, $payload, true, (int) ($cq['message']['message_id'] ?? 0));
            return;
        }
        if (strpos($data, 'q:') === 0) {
            $parts = explode(':', $data);
            $postId = (int) ($parts[1] ?? 0);
            $fileId = (int) ($parts[2] ?? 0);
            $this->tg->answerCallback($cbId);
            if (!$this->gate($chatId, $userId, 'q_' . $postId . '_' . $fileId, true)) {
                return;
            }
            $this->sendOneFile($chatId, $postId, $fileId);
            return;
        }
        if (strpos($data, 'g:') === 0) {
            $parts = explode(':', $data);
            $postId = (int) ($parts[1] ?? 0);
            $qkey = (string) ($parts[2] ?? '');
            $season = (int) ($parts[3] ?? 0);
            $this->tg->answerCallback($cbId);
            if (!$this->gate($chatId, $userId, 'g_' . $postId . '_' . $qkey . '_' . $season, true)) {
                return;
            }
            $this->sendSeriesGroup($chatId, $postId, $qkey, $season);
            return;
        }
        $this->tg->answerCallback($cbId);
    }

    public function start(int $chatId, int $userId, string $payload): void
    {
        $payload = trim($payload);
        if ($payload === '') {
            $this->tg->sendMessage($chatId, "سلام 👋\nاز دکمه‌های <b>لینک‌ها</b> و <b>فایل‌ها</b> زیر پست‌های کانال استفاده کنید تا محتوا برایتان ارسال شود.");
            return;
        }
        $this->deliver($chatId, $userId, $payload, false, 0);
    }

    private function deliver(int $chatId, int $userId, string $payload, bool $refreshJoin, int $editMid): void
    {
        $payload = str_replace(' ', '', $payload);
        if (!$this->gate($chatId, $userId, $payload, $refreshJoin, $editMid)) {
            return;
        }
        if ($editMid > 0) {
            $this->tg->deleteMessage($chatId, $editMid);
        }

        if (preg_match('/^l[_:](\d+)$/i', $payload, $m)) {
            $this->sendLinks($chatId, (int) $m[1]);
            return;
        }
        if (preg_match('/^f[_:](\d+)$/i', $payload, $m)) {
            $this->sendFilesMenu($chatId, (int) $m[1]);
            return;
        }
        if (preg_match('/^q[_:](\d+)[_:](\d+)$/i', $payload, $m)) {
            $this->sendOneFile($chatId, (int) $m[1], (int) $m[2]);
            return;
        }
        if (preg_match('/^g[_:](\d+)[_:]([A-Za-z0-9]+)[_:](\d+)$/i', $payload, $m)) {
            $this->sendSeriesGroup($chatId, (int) $m[1], (string) $m[2], (int) $m[3]);
            return;
        }
        $this->tg->sendMessage($chatId, 'درخواست نامعتبر است. از دکمه‌های کانال استفاده کنید.');
    }

    private function gate(int $chatId, int $userId, string $payload, bool $refresh, int $editMid = 0): bool
    {
        $check = ForcedJoin::check($this->tg, $userId, $refresh);
        if ($check['ok']) {
            return true;
        }
        [$text, $markup] = ForcedJoin::prompt($check['missing'], $payload);
        if ($editMid > 0) {
            $this->tg->editMessageText($chatId, $editMid, $text, ['reply_markup' => $markup]);
        } else {
            $this->tg->sendMessage($chatId, $text, ['reply_markup' => $markup]);
        }
        return false;
    }

    private function sendLinks(int $chatId, int $postId): void
    {
        $post = PostService::get($postId);
        if (!$post || $post['status'] !== 'published') {
            $this->tg->sendMessage($chatId, 'این پست در دسترس نیست.');
            return;
        }
        $msgs = PostService::linkMessages($postId);
        $sec = Settings::deleteAfter();
        $sent = 0;
        foreach ($msgs as $m) {
            $privChat = (int) ($m['private_chat_id'] ?? 0);
            $privMid = (int) ($m['private_message_id'] ?? 0);
            $res = null;
            if ($privChat && $privMid) {
                $res = $this->tg->copyMessage($chatId, $privChat, $privMid);
            }
            if (empty($res['ok'])) {
                $res = $this->resendLinkMessage($chatId, $m);
            }
            if (empty($res['ok'])) {
                Logger::error('send link post fail post=' . $postId . ' ' . ($res['description'] ?? ''));
                continue;
            }
            $sent++;
            $mid = $this->tg->messageId($res);
            if ($mid) {
                Scheduler::later($chatId, $mid, $sec);
            }
        }
        if ($sent > 0) {
            return;
        }

        $links = PostService::links($postId);
        if ($links === []) {
            $this->tg->sendMessage($chatId, 'برای این پست لینکی ثبت نشده.');
            return;
        }
        $body = "🔗 <b>لینک‌های دانلود</b>\n\n";
        foreach ($links as $i => $l) {
            $label = h((string) ($l['label'] ?: 'لینک ' . ($i + 1)));
            $url = h((string) $l['url']);
            $body .= ($i + 1) . ". <a href=\"{$url}\">{$label}</a>\n<code>{$url}</code>\n\n";
        }
        $body .= "⚠️ این پیام تا {$sec} ثانیه دیگر حذف می‌شود.";
        $res = $this->tg->sendMessage($chatId, $body, ['disable_web_page_preview' => false]);
        $mid = $this->tg->messageId($res);
        if ($mid) {
            Scheduler::later($chatId, $mid, $sec);
        }
    }

    private function resendLinkMessage(int $chatId, array $m): array
    {
        $html = (string) ($m['caption_html'] ?? '');
        $type = (string) ($m['media_type'] ?? 'text');
        $fileId = (string) ($m['media_file_id'] ?? '');
        if ($type === 'photo' && $fileId !== '') {
            return $this->tg->sendPhoto($chatId, $fileId, $html, ['parse_mode' => 'HTML']);
        }
        if ($type === 'document' && $fileId !== '') {
            $extra = ['parse_mode' => 'HTML'];
            if ($html !== '') {
                $extra['caption'] = $html;
            }
            return $this->tg->sendDocument($chatId, $fileId, $extra);
        }
        $text = $html !== '' ? $html : '🔗 لینک‌ها';
        return $this->tg->sendMessage($chatId, $text, [
            'parse_mode' => 'HTML',
            'disable_web_page_preview' => false,
        ]);
    }

    private function sendFilesMenu(int $chatId, int $postId): void
    {
        $post = PostService::get($postId);
        if (!$post || $post['status'] !== 'published') {
            $this->tg->sendMessage($chatId, 'این پست در دسترس نیست.');
            return;
        }
        $files = PostService::files($postId);
        if ($files === []) {
            $this->tg->sendMessage($chatId, 'برای این پست فایلی ثبت نشده.');
            return;
        }
        if (count($files) === 1) {
            $this->sendOneFile($chatId, $postId, (int) $files[0]['id']);
            return;
        }
        $rows = [];
        if (SeriesParser::isSeries($files)) {
            foreach (SeriesParser::groups($files) as $g) {
                $rows[] = [btn((string) $g['label'], 'g:' . $postId . ':' . $g['quality_key'] . ':' . $g['season'])];
            }
            foreach ($files as $f) {
                if (!SeriesParser::isSeriesFile($f)) {
                    $rows[] = [btn(QualityDetector::buttonLabel($f), 'q:' . $postId . ':' . $f['id'])];
                }
            }
        } else {
            foreach ($files as $f) {
                $rows[] = [btn(QualityDetector::buttonLabel($f), 'q:' . $postId . ':' . $f['id'])];
            }
        }
        $sec = Settings::deleteAfter();
        $hint = SeriesParser::isSeries($files)
            ? "📺 فصل و کیفیت مورد نظر را انتخاب کنید.\nپس از ارسال، فایل‌ها تا {$sec} ثانیه دیگر حذف می‌شوند."
            : "🎞 کیفیت مورد نظر را انتخاب کنید.\nپس از ارسال، فایل تا {$sec} ثانیه دیگر حذف می‌شود.";
        $res = $this->tg->sendMessage($chatId, $hint, ['reply_markup' => kb($rows)]);
        $mid = $this->tg->messageId($res);
        if ($mid) {
            Scheduler::later($chatId, $mid, $sec);
        }
    }

    private function sendOneFile(int $chatId, int $postId, int $fileRowId): void
    {
        $file = DB::one('SELECT * FROM post_files WHERE id = ? AND post_id = ?', [$fileRowId, $postId]);
        if (!$file) {
            $this->tg->sendMessage($chatId, 'فایل پیدا نشد.');
            return;
        }
        $sec = Settings::deleteAfter();
        $caption = '🎞 ' . (string) $file['quality'];
        $season = (int) ($file['season'] ?? 0);
        $episode = (int) ($file['episode'] ?? 0);
        if ($season > 0 || $episode > 0) {
            $caption .= ' · ' . SeriesParser::seasonLabel($season > 0 ? $season : 1);
            if ($episode > 0) {
                $caption .= ' قسمت ' . $episode;
            }
        }
        $caption .= "\n⚠️ حذف تا {$sec} ثانیه دیگر";
        $res = null;

        $privChat = (int) ($file['private_chat_id'] ?? 0);
        $privMid  = (int) ($file['private_message_id'] ?? 0);
        if ($privChat && $privMid) {
            $res = $this->tg->copyMessage($chatId, $privChat, $privMid, [
                'caption' => $caption,
            ]);
        }

        if (empty($res['ok'])) {
            if (($file['file_type'] ?? 'video') === 'document') {
                $res = $this->tg->sendDocument($chatId, (string) $file['file_id'], ['caption' => $caption]);
            } else {
                $res = $this->tg->sendVideo($chatId, (string) $file['file_id'], ['caption' => $caption]);
            }
        }

        if (empty($res['ok'])) {
            $this->tg->sendMessage($chatId, 'ارسال فایل ناموفق بود. بعداً دوباره تلاش کنید.');
            Logger::error('send file fail post=' . $postId . ' ' . ($res['description'] ?? ''));
            return;
        }
        $mid = $this->tg->messageId($res);
        if ($mid) {
            Scheduler::later($chatId, $mid, $sec);
        }
    }

    private function sendSeriesGroup(int $chatId, int $postId, string $qualityKey, int $season): void
    {
        $post = PostService::get($postId);
        if (!$post || $post['status'] !== 'published') {
            $this->tg->sendMessage($chatId, 'این پست در دسترس نیست.');
            return;
        }
        $files = PostService::files($postId);
        $batch = [];
        foreach (SeriesParser::groups($files) as $g) {
            if ((string) $g['quality_key'] === $qualityKey && (int) $g['season'] === $season) {
                $batch = $g['files'];
                break;
            }
        }
        if ($batch === []) {
            $this->tg->sendMessage($chatId, 'فایلی برای این فصل و کیفیت پیدا نشد.');
            return;
        }
        $sec = Settings::deleteAfter();
        $label = SeriesParser::buttonLabel($qualityKey, $season);
        $n = count($batch);
        $head = $this->tg->sendMessage($chatId, "📺 <b>{$label}</b> · {$n} قسمت\nپس از ارسال، فایل‌ها تا {$sec} ثانیه دیگر حذف می‌شوند.");
        $hid = $this->tg->messageId($head);
        if ($hid) {
            Scheduler::later($chatId, $hid, $sec);
        }
        foreach ($batch as $f) {
            $this->sendOneFile($chatId, $postId, (int) $f['id']);
        }
    }

    private function touchUser(array $from): void
    {
        $id = (int) ($from['id'] ?? 0);
        if ($id <= 0) {
            return;
        }
        $username = $from['username'] ?? null;
        $name = $from['first_name'] ?? null;
        $now = time();
        if (DB::isSqlite()) {
            DB::exec(
                'INSERT INTO bot_users (user_id, username, first_name, last_seen) VALUES (?,?,?,?)
                 ON CONFLICT(user_id) DO UPDATE SET username = excluded.username, first_name = excluded.first_name, last_seen = excluded.last_seen',
                [$id, $username, $name, $now]
            );
        } else {
            DB::exec(
                'INSERT INTO bot_users (user_id, username, first_name, last_seen) VALUES (?,?,?,?)
                 ON DUPLICATE KEY UPDATE username = VALUES(username), first_name = VALUES(first_name), last_seen = VALUES(last_seen)',
                [$id, $username, $name, $now]
            );
        }
    }
}
