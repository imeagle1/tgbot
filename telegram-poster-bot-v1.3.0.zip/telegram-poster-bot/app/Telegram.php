<?php
declare(strict_types=1);

final class Telegram
{
    private string $token;
    private string $api;

    public function __construct()
    {
        $this->token = (string) Config::get('bot_token', '');
        $this->api = 'https://api.telegram.org/bot' . $this->token . '/';
    }

    public function request(string $method, array $params = [], int $timeout = 25): array
    {
        if (isset($params['parse_mode']) && $params['parse_mode'] === '') {
            unset($params['parse_mode']);
        }
        $ch = curl_init($this->api . $method);
        $payload = json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $raw = curl_exec($ch);
        $err = curl_error($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($raw === false) {
            Logger::error("Telegram curl {$method}: {$err}");
            return ['ok' => false, 'description' => $err, 'error_code' => 0];
        }

        $decoded = json_decode((string) $raw, true);
        if (!is_array($decoded)) {
            Logger::error("Telegram bad json {$method} HTTP {$code}: " . substr((string) $raw, 0, 300));
            return ['ok' => false, 'description' => 'bad json', 'error_code' => $code];
        }

        if (empty($decoded['ok']) && ($decoded['error_code'] ?? 0) == 429) {
            $wait = (int) ($decoded['parameters']['retry_after'] ?? 1);
            if ($wait > 0 && $wait <= 5) {
                sleep($wait);
                return $this->request($method, $params, $timeout);
            }
        }

        if (empty($decoded['ok'])) {
            Logger::info("Telegram {$method} fail: " . ($decoded['description'] ?? ''));
        }
        return $decoded;
    }

    public function getMe(): array
    {
        return $this->request('getMe', [], 15);
    }

    public function sendMessage(int $chatId, string $text, array $extra = []): array
    {
        $params = array_merge([
            'chat_id'    => $chatId,
            'text'       => $text,
            'parse_mode' => 'HTML',
            'disable_web_page_preview' => true,
        ], $extra);
        return $this->request('sendMessage', $params);
    }

    public function sendPhoto(int $chatId, string $fileId, string $caption = '', array $extra = []): array
    {
        $params = array_merge([
            'chat_id' => $chatId,
            'photo'   => $fileId,
            'caption' => $caption,
            'parse_mode' => 'HTML',
        ], $extra);
        if ($caption === '') {
            unset($params['caption'], $params['parse_mode']);
        }
        if (isset($params['parse_mode']) && $params['parse_mode'] === '') {
            unset($params['parse_mode']);
        }
        return $this->request('sendPhoto', $params);
    }

    public function sendVideo(int $chatId, string $fileId, array $extra = []): array
    {
        return $this->request('sendVideo', array_merge([
            'chat_id' => $chatId,
            'video'   => $fileId,
        ], $extra));
    }

    public function sendDocument(int $chatId, string $fileId, array $extra = []): array
    {
        return $this->request('sendDocument', array_merge([
            'chat_id'  => $chatId,
            'document' => $fileId,
        ], $extra));
    }

    public function copyMessage(int $toChatId, int $fromChatId, int $messageId, array $extra = []): array
    {
        return $this->request('copyMessage', array_merge([
            'chat_id'      => $toChatId,
            'from_chat_id' => $fromChatId,
            'message_id'   => $messageId,
        ], $extra));
    }

    public function forwardMessage(int $toChatId, int $fromChatId, int $messageId): array
    {
        return $this->request('forwardMessage', [
            'chat_id'      => $toChatId,
            'from_chat_id' => $fromChatId,
            'message_id'   => $messageId,
        ]);
    }

    public function deleteMessage(int $chatId, int $messageId): array
    {
        return $this->request('deleteMessage', [
            'chat_id'    => $chatId,
            'message_id' => $messageId,
        ], 10);
    }

    public function answerCallback(string $id, string $text = '', bool $alert = false, ?string $url = null): array
    {
        $params = ['callback_query_id' => $id];
        if ($text !== '') {
            $params['text'] = mb_substr($text, 0, 180);
            $params['show_alert'] = $alert;
        }
        if ($url !== null && $url !== '') {
            $params['url'] = $url;
        }
        return $this->request('answerCallbackQuery', $params, 10);
    }

    public function editMessageText(int $chatId, int $messageId, string $text, array $extra = []): array
    {
        return $this->request('editMessageText', array_merge([
            'chat_id'    => $chatId,
            'message_id' => $messageId,
            'text'       => $text,
            'parse_mode' => 'HTML',
            'disable_web_page_preview' => true,
        ], $extra));
    }

    public function editMarkup(int $chatId, int $messageId, array $markup): array
    {
        return $this->request('editMessageReplyMarkup', [
            'chat_id'      => $chatId,
            'message_id'   => $messageId,
            'reply_markup' => $markup,
        ]);
    }

    public function getChat(int $chatId): array
    {
        return $this->request('getChat', ['chat_id' => $chatId], 15);
    }

    public function getChatMember(int $chatId, int $userId): array
    {
        return $this->request('getChatMember', [
            'chat_id' => $chatId,
            'user_id' => $userId,
        ], 12);
    }

    /**
     * Parallel membership checks for forced-join (up to 20 channels).
     * @return array<string,array> keyed by chat_id
     */
    public function getChatMembersMany(array $chatIds, int $userId): array
    {
        $chatIds = array_values(array_unique(array_map('intval', $chatIds)));
        if ($chatIds === []) {
            return [];
        }
        $mh = curl_multi_init();
        $handles = [];
        foreach ($chatIds as $cid) {
            $ch = curl_init($this->api . 'getChatMember');
            $payload = json_encode(['chat_id' => $cid, 'user_id' => $userId], JSON_UNESCAPED_UNICODE);
            curl_setopt_array($ch, [
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => $payload,
                CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => 5,
                CURLOPT_TIMEOUT        => 12,
                CURLOPT_SSL_VERIFYPEER => true,
            ]);
            $handles[$cid] = $ch;
            curl_multi_add_handle($mh, $ch);
        }
        $running = null;
        do {
            $status = curl_multi_exec($mh, $running);
            if ($running) {
                curl_multi_select($mh, 1.0);
            }
        } while ($running && $status === CURLM_OK);

        $out = [];
        foreach ($handles as $cid => $ch) {
            $raw = curl_multi_getcontent($ch);
            $decoded = is_string($raw) ? json_decode($raw, true) : null;
            $out[(string) $cid] = is_array($decoded) ? $decoded : ['ok' => false];
            curl_multi_remove_handle($mh, $ch);
            curl_close($ch);
        }
        curl_multi_close($mh);
        return $out;
    }

    public function createChatInviteLink(int $chatId): array
    {
        return $this->request('createChatInviteLink', [
            'chat_id' => $chatId,
            'name'    => 'force-join',
        ], 15);
    }

    public function setWebhook(string $url, string $secret): array
    {
        return $this->request('setWebhook', [
            'url'                  => $url,
            'secret_token'         => $secret,
            'max_connections'      => 40,
            'drop_pending_updates' => false,
            'allowed_updates'      => [
                'message',
                'callback_query',
                'my_chat_member',
            ],
        ], 20);
    }

    public function messageId(array $res): ?int
    {
        if (!empty($res['ok']) && isset($res['result']['message_id'])) {
            return (int) $res['result']['message_id'];
        }
        if (!empty($res['ok']) && isset($res['result']['message_id'])) {
            return (int) $res['result']['message_id'];
        }
        return isset($res['result']['message_id']) ? (int) $res['result']['message_id'] : null;
    }

    public function botLink(string $payload = ''): string
    {
        $u = ltrim((string) (Settings::get('bot_username') ?: Config::get('bot_username', '')), '@');
        if ($u === '') {
            $me = $this->getMe();
            $u = (string) ($me['result']['username'] ?? '');
            if ($u !== '') {
                Settings::set('bot_username', $u);
            }
        }
        $base = 'https://t.me/' . $u;
        return $payload === '' ? $base : $base . '?start=' . rawurlencode($payload);
    }
}
