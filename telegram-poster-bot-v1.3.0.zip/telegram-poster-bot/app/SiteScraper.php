<?php
declare(strict_types=1);

final class SiteScraper
{
    public static function isPageUrl(string $text): bool
    {
        $text = trim($text);
        if (!preg_match('~^https?://\S+$~i', $text)) {
            return false;
        }
        if (!filter_var($text, FILTER_VALIDATE_URL)) {
            return false;
        }
        $host = strtolower((string) (parse_url($text, PHP_URL_HOST) ?? ''));
        $host = preg_replace('/^www\./', '', $host) ?? $host;
        if ($host === '') {
            return false;
        }
        if (preg_match('/(^|\.)(t\.me|telegram\.me|telegram\.org|telegra\.ph)$/i', $host)) {
            return false;
        }
        $path = (string) (parse_url($text, PHP_URL_PATH) ?? '');
        if (preg_match('/\.(mp4|mkv|avi|zip|rar|7z|pdf|jpg|jpeg|png|webp|gif)(\?|$)/i', $path)) {
            return false;
        }
        return true;
    }

    /**
     * @return array<string,mixed>|null
     */
    public static function scrape(string $url): ?array
    {
        $html = self::getWebPage($url);
        if ($html === '' || $html === false) {
            return null;
        }

        libxml_use_internal_errors(true);
        $dom = new DOMDocument();
        @$dom->loadHTML('<?xml encoding="UTF-8">' . $html);
        libxml_clear_errors();
        $xpath = new DOMXPath($dom);

        $title = self::xpathValue($xpath, "//*[contains(@class, 'entry-title')]");
        if ($title === '') {
            $title = self::xpathValue($xpath, '//title');
        }
        if ($title === '') {
            return null;
        }

        $yearFromUrl = null;
        if (preg_match('/-(\d{4})\/?$/', rtrim($url, '/'), $m)) {
            $yearFromUrl = (int) $m[1];
        }
        if ($yearFromUrl) {
            if (strpos($title, (string) $yearFromUrl) === false) {
                $title = trim($title) . ' ' . $yearFromUrl;
            }
        } else {
            $releaseNode = $xpath->query("//div[contains(@class, 'align-items-center') and contains(., 'اکران')]//span[@dir='ltr']");
            if ($releaseNode && $releaseNode->length > 0) {
                $jalaliDate = trim($releaseNode->item(0)->nodeValue ?? '');
                $dateParts = explode('/', $jalaliDate);
                if (count($dateParts) === 3) {
                    $gregorianDate = self::jalaliToGregorian((int) $dateParts[0], (int) $dateParts[1], (int) $dateParts[2]);
                    $gYear = $gregorianDate[0];
                    if ($gYear > 1900 && strpos($title, (string) $gYear) === false) {
                        $title = trim($title) . ' ' . $gYear;
                    }
                }
            }
        }

        $poster = self::xpathAttr($xpath, "//*[contains(@class, 'entry-poster')]//img", 'src');
        if ($poster === '') {
            $poster = self::xpathAttr($xpath, "//*[contains(@class, 'entry-poster')]//img", 'data-src');
        }
        $poster = self::absolutize($url, $poster);

        $data = [
            'title'        => $title,
            'poster'       => $poster,
            'satisfaction' => self::xpathValue($xpath, "//*[contains(@class, 'feedback-satisfaction')]"),
            'original_url' => $url,
            'imdb'         => '',
            'genres'       => '',
            'excerpt'      => '',
            'links'        => [
                'دوبله فارسی'  => [],
                'زیرنویس چسبیده' => [],
            ],
        ];

        $rawImdb = self::xpathValue($xpath, "//*[contains(@class, 'col-auto col-lg-auto d-flex align-items-center gap-05 my-3')]");
        if (preg_match('/[0-9]+(?:\.[0-9]+)?/', $rawImdb, $matches)) {
            $data['imdb'] = $matches[0];
        }

        $genreNodes = $xpath->query("//*[contains(@class, 'entry-genres')]//a");
        $cleanGenres = [];
        if ($genreNodes) {
            foreach ($genreNodes as $gNode) {
                $gText = trim($gNode->nodeValue ?? '');
                if ($gText === '') {
                    continue;
                }
                if (strpos($gText, 'دوبله') === false && strpos($gText, 'اضافه شد') === false && strpos($gText, 'زیرنویس') === false) {
                    $cleanGenres[] = $gText;
                }
            }
        }
        $data['genres'] = implode('، ', array_unique($cleanGenres));

        $excerpt = self::xpathValue($xpath, "//*[contains(@class, 'entry-excerpt')]");
        $excerpt = preg_replace('/^(خلاصه داستان\s*[:\-]\s*)/u', '', $excerpt) ?? $excerpt;
        if (mb_strlen($excerpt, 'UTF-8') > 120) {
            $excerpt = mb_substr($excerpt, 0, 117, 'UTF-8') . '...';
        }
        $data['excerpt'] = $excerpt;

        $data['links']['دوبله فارسی'] = self::extractLinksWithQuality($xpath, "//*[contains(@class, 'download-list') and contains(@class, 'dubbled')]");
        $data['links']['زیرنویس چسبیده'] = self::extractLinksWithQuality($xpath, "//*[contains(@class, 'download-list') and contains(@class, 'hardsub')]");

        return $data;
    }

    public static function hasLinks(array $movie): bool
    {
        return !empty($movie['links']['دوبله فارسی']) || !empty($movie['links']['زیرنویس چسبیده']);
    }

    public static function qualitySummary(array $movie): string
    {
        $lines = ["📥 <b>لینک‌های دانلود</b>:"];
        $dub = $movie['links']['دوبله فارسی'] ?? [];
        $sub = $movie['links']['زیرنویس چسبیده'] ?? [];
        if ($dub !== []) {
            $lines[] = 'دوبله فارسی بدون حذفیات:';
            foreach (array_keys($dub) as $q) {
                $lines[] = $q;
            }
        }
        if ($sub !== []) {
            $lines[] = 'زیرنویس فارسی چسبیده بدون حذفیات:';
            foreach (array_keys($sub) as $q) {
                $lines[] = $q;
            }
        }
        if (count($lines) === 1) {
            return '';
        }
        return implode("\n", $lines);
    }

    public static function publicCaption(array $movie): string
    {
        $header = '🎬 <b>' . h($movie['title'] ?? '') . "</b>\n";
        if (!empty($movie['links']['دوبله فارسی'])) {
            $header .= "<b>🎙دوبله فارسی اضافه شد</b>\n\n";
        }
        if (!empty($movie['genres'])) {
            $header .= '🎭 ژانر: ' . h((string) $movie['genres']) . "\n";
        }
        if (!empty($movie['imdb'])) {
            $rating = (string) $movie['imdb'];
            if (strpos($rating, '/10') === false) {
                $rating .= '/10';
            }
            $header .= "‏🥇 IMDB امتیاز: ‏" . h($rating) . "\n";
        }
        if (!empty($movie['satisfaction'])) {
            $header .= '⭐️ رضایت: ' . h((string) $movie['satisfaction']) . "\n";
        }

        $summary = self::qualitySummary($movie);
        $excerptPrefix = '📝 خلاصه داستان: ';
        $tail = $summary !== '' ? "\n\n" . $summary : '';

        $fixed = mb_strlen(strip_tags($header . $excerptPrefix . $tail), 'UTF-8');
        $budget = 980 - $fixed;
        $excerpt = trim((string) ($movie['excerpt'] ?? ''));
        if ($budget <= 0) {
            $excerpt = '';
        } elseif (mb_strlen($excerpt, 'UTF-8') > $budget) {
            $cut = max(0, $budget - 3);
            $excerpt = $cut > 0 ? (mb_substr($excerpt, 0, $cut, 'UTF-8') . '...') : '';
        }

        $body = $header;
        if ($excerpt !== '') {
            $body .= $excerptPrefix . h($excerpt);
        }
        return trim($body . $tail);
    }

    public static function linkCaption(array $movie): string
    {
        $text = '🎬 <b>' . h($movie['title'] ?? '') . "</b>\n\n";
        $text .= "📥 <b>لینک‌های دانلود</b>\n";
        $dub = $movie['links']['دوبله فارسی'] ?? [];
        $sub = $movie['links']['زیرنویس چسبیده'] ?? [];
        if ($dub !== []) {
            $text .= "🎙 دوبله فارسی بدون حذفیات (دو زبانه):\n";
            foreach ($dub as $q => $link) {
                $text .= '🔗 <a href="' . h((string) $link) . '">' . h((string) $q) . "</a>\n";
            }
        }
        if ($sub !== []) {
            $text .= "📝 زیرنویس فارسی چسبیده بدون حذفیات:\n";
            foreach ($sub as $q => $link) {
                $text .= '🔗 <a href="' . h((string) $link) . '">' . h((string) $q) . "</a>\n";
            }
        }
        if ($dub === [] && $sub === []) {
            $text .= "لینک دانلودی یافت نشد.\n";
        }
        $text = trim($text);
        if (mb_strlen($text) > 1024) {
            $text = mb_substr($text, 0, 1021) . '…';
        }
        return $text;
    }

    private static function extractLinksWithQuality(DOMXPath $xpath, string $baseQuery): array
    {
        $links = [];
        $nodes = $xpath->query($baseQuery . '//a');
        if (!$nodes) {
            return $links;
        }
        foreach ($nodes as $node) {
            if (!$node instanceof DOMElement) {
                continue;
            }
            $text = trim($node->nodeValue ?? '');
            if (strpos($text, 'دانلود') === false && strpos($text, 'صوت') === false) {
                continue;
            }
            $href = trim($node->getAttribute('href'));
            if ($href === '') {
                continue;
            }

            $quality = 'نامشخص';
            $qNodes = $xpath->query("./preceding::span[contains(@class, 'text') and @dir='ltr'][1]", $node);
            if ($qNodes && $qNodes->length > 0) {
                $quality = trim($qNodes->item(0)->nodeValue ?? '');
            } else {
                $qNodesBackup = $xpath->query("./preceding::span[contains(@class, 'text')][1]", $node);
                if ($qNodesBackup && $qNodesBackup->length > 0) {
                    $quality = trim($qNodesBackup->item(0)->nodeValue ?? '');
                }
            }
            $quality = preg_replace('/^کیفیت\s*[:\-]?\s*/ui', '', $quality) ?? $quality;
            $quality = trim($quality);

            if ($quality === 'صوت دوبله فارسی') {
                $liNodes = $xpath->query('./ancestor::li[1]', $node);
                if ($liNodes && $liNodes->length > 0) {
                    $liNode = $liNodes->item(0);
                    $studio = '';
                    $descNodes = $xpath->query(".//div[contains(span[@class='text-muted'], 'توضیحات')]", $liNode);
                    if ($descNodes && $descNodes->length > 0) {
                        $descText = $descNodes->item(0)->nodeValue ?? '';
                        $studio = trim(str_replace(['توضیحات', ':'], '', $descText));
                    } else {
                        $encNodes = $xpath->query(".//div[contains(span[@class='text-muted'], 'انکودر')]", $liNode);
                        if ($encNodes && $encNodes->length > 0) {
                            $encText = $encNodes->item(0)->nodeValue ?? '';
                            $studio = trim(str_replace(['انکودر', ':'], '', $encText));
                        }
                    }
                    if ($studio !== '') {
                        $quality .= ' (' . $studio . ')';
                    }
                }
            }

            if (!isset($links[$quality])) {
                $links[$quality] = $href;
            } else {
                $links[$quality . ' (لینک کمکی)'] = $href;
            }
        }
        return $links;
    }

    private static function getWebPage(string $url)
    {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            CURLOPT_TIMEOUT        => 18,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $html = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        if ($html === false) {
            Logger::error('scrape curl: ' . $err . ' url=' . $url);
            return false;
        }
        return (string) $html;
    }

    private static function xpathValue(DOMXPath $xpath, string $query): string
    {
        $nodes = $xpath->query($query);
        if (!$nodes || $nodes->length === 0) {
            return '';
        }
        return trim(strip_tags($nodes->item(0)->nodeValue ?? ''));
    }

    private static function xpathAttr(DOMXPath $xpath, string $query, string $attr): string
    {
        $nodes = $xpath->query($query);
        if (!$nodes || $nodes->length === 0) {
            return '';
        }
        $node = $nodes->item(0);
        if (!$node instanceof DOMElement) {
            return '';
        }
        return trim($node->getAttribute($attr));
    }

    private static function absolutize(string $pageUrl, string $src): string
    {
        $src = trim($src);
        if ($src === '') {
            return '';
        }
        if (preg_match('~^https?://~i', $src)) {
            return $src;
        }
        if (strpos($src, '//') === 0) {
            $scheme = parse_url($pageUrl, PHP_URL_SCHEME) ?: 'https';
            return $scheme . ':' . $src;
        }
        $parts = parse_url($pageUrl);
        if (!is_array($parts) || empty($parts['host'])) {
            return $src;
        }
        $origin = ($parts['scheme'] ?? 'https') . '://' . $parts['host'];
        if (!empty($parts['port'])) {
            $origin .= ':' . $parts['port'];
        }
        if (strpos($src, '/') === 0) {
            return $origin . $src;
        }
        $dir = isset($parts['path']) ? rtrim(dirname($parts['path']), '/') : '';
        return $origin . $dir . '/' . $src;
    }

    /**
     * @return array{0:int,1:int,2:int}
     */
    private static function jalaliToGregorian(int $jy, int $jm, int $jd): array
    {
        $jy += 1595;
        $days = -355668 + (365 * $jy) + ((int) ($jy / 33) * 8) + (int) ((($jy % 33) + 3) / 4) + $jd;
        if ($jm < 7) {
            $days += ($jm - 1) * 31;
        } else {
            $days += (($jm - 7) * 30) + 186;
        }
        $gy = 400 * (int) ($days / 146097);
        $days %= 146097;
        if ($days > 36524) {
            $gy += 100 * (int) (--$days / 36524);
            $days %= 36524;
            if ($days >= 365) {
                $days++;
            }
        }
        $gy += 4 * (int) ($days / 1461);
        $days %= 1461;
        if ($days > 365) {
            $gy += (int) (($days - 1) / 365);
            $days = ($days - 1) % 365;
        }
        $gd = $days + 1;
        $salA = [0, 31, (($gy % 4 === 0 && $gy % 100 !== 0) || ($gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        $gm = 0;
        for (; $gm < 13 && $gd > $salA[$gm]; $gm++) {
            $gd -= $salA[$gm];
        }
        return [$gy, $gm, $gd];
    }
}
