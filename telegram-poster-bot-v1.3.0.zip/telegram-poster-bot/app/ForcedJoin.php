<?php
declare(strict_types=1);

final class ForcedJoin
{
    public static function activeChannels(): array
    {
        return DB::all('SELECT * FROM forced_channels WHERE is_active = 1 ORDER BY sort_order ASC, id ASC');
    }

    /**
     * @return array{ok:bool, missing:array}
     */
    public static function check(Telegram $tg, int $userId, bool $forceRefresh = false): array
    {
        if (!Settings::forceJoinEnabled()) {
            return ['ok' => true, 'missing' => []];
        }
        $channels = self::activeChannels();
        if ($channels === []) {
            return ['ok' => true, 'missing' => []];
        }

        $needApi = [];
        $missing = [];
        $now = time();
        $ttl = 40;

        foreach ($channels as $ch) {
            $cid = (int) $ch['chat_id'];
            if (!$forceRefresh) {
                $row = DB::one('SELECT is_member, checked_at FROM membership_cache WHERE user_id = ? AND chat_id = ?', [$userId, $cid]);
                if ($row && ($now - (int) $row['checked_at']) < $ttl) {
                    if (!(int) $row['is_member']) {
                        $missing[] = $ch;
                    }
                    continue;
                }
            }
            $needApi[] = $ch;
        }

        if ($needApi !== []) {
            $ids = array_map(static fn($c) => (int) $c['chat_id'], $needApi);
            $results = $tg->getChatMembersMany($ids, $userId);
            foreach ($needApi as $ch) {
                $cid = (int) $ch['chat_id'];
                $res = $results[(string) $cid] ?? ['ok' => false];
                $status = (string) ($res['result']['status'] ?? '');
                $member = $res['ok'] && in_array($status, ['creator', 'administrator', 'member', 'restricted'], true);
                // restricted still counts as member unless is_member is false
                if ($status === 'restricted' && isset($res['result']['is_member']) && !$res['result']['is_member']) {
                    $member = false;
                }
                if ($status === 'left' || $status === 'kicked') {
                    $member = false;
                }
                self::cache($userId, $cid, $member, $now);
                if (!$member) {
                    $missing[] = $ch;
                }
            }
        }

        return ['ok' => $missing === [], 'missing' => $missing];
    }

    private static function cache(int $userId, int $chatId, bool $member, int $now): void
    {
        if (DB::isSqlite()) {
            DB::exec(
                'INSERT INTO membership_cache (user_id, chat_id, is_member, checked_at) VALUES (?,?,?,?)
                 ON CONFLICT(user_id, chat_id) DO UPDATE SET is_member = excluded.is_member, checked_at = excluded.checked_at',
                [$userId, $chatId, $member ? 1 : 0, $now]
            );
        } else {
            DB::exec(
                'INSERT INTO membership_cache (user_id, chat_id, is_member, checked_at) VALUES (?,?,?,?)
                 ON DUPLICATE KEY UPDATE is_member = VALUES(is_member), checked_at = VALUES(checked_at)',
                [$userId, $chatId, $member ? 1 : 0, $now]
            );
        }
    }

    public static function joinKeyboard(array $missing, string $continuePayload): array
    {
        $rows = [];
        $i = 1;
        foreach ($missing as $ch) {
            $title = (string) ($ch['title'] ?: ($ch['username'] ? '@' . $ch['username'] : ('کانال ' . $i)));
            $url = (string) ($ch['invite_link'] ?? '');
            if ($url === '' && !empty($ch['username'])) {
                $url = 'https://t.me/' . ltrim((string) $ch['username'], '@');
            }
            if ($url === '') {
                $i++;
                continue;
            }
            $rows[] = [urlBtn('📢 عضویت در ' . $title, $url)];
            $i++;
        }
        $rows[] = [btn('✅ عضو شدم — بررسی', 'j:' . $continuePayload)];
        return kb($rows);
    }

    public static function prompt(array $missing, string $continuePayload): array
    {
        $n = count($missing);
        $text = "🔒 <b>عضویت اجباری</b>\n\n"
            . "برای دریافت محتوا باید عضو {$n} کانال زیر شوید، سپس دکمه «عضو شدم» را بزنید.";
        return [$text, self::joinKeyboard($missing, $continuePayload)];
    }
}
