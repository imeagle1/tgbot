<?php
declare(strict_types=1);

final class Settings
{
    private static ?array $cache = null;

    public static function flush(): void
    {
        self::$cache = null;
    }

    public static function all(): array
    {
        if (self::$cache === null) {
            self::$cache = [];
            try {
                foreach (DB::all('SELECT k, v FROM settings') as $row) {
                    $decoded = json_decode((string) $row['v'], true);
                    self::$cache[$row['k']] = $decoded === null && $row['v'] !== 'null' ? $row['v'] : $decoded;
                }
            } catch (Throwable $e) {
                self::$cache = [];
            }
        }
        return self::$cache;
    }

    public static function get(string $key, $default = null)
    {
        $all = self::all();
        return array_key_exists($key, $all) ? $all[$key] : $default;
    }

    public static function set(string $key, $value): void
    {
        DB::upsertSetting($key, $value);
    }

    public static function privateChannelId(): ?int
    {
        $v = self::get('private_channel_id');
        return $v ? (int) $v : null;
    }

    public static function publicChannelId(): ?int
    {
        $v = self::get('public_channel_id');
        return $v ? (int) $v : null;
    }

    public static function footer(): string
    {
        return trim((string) self::get('footer', ''));
    }

    public static function deleteAfter(): int
    {
        $n = (int) self::get('delete_after', 30);
        return max(5, min(300, $n));
    }

    public static function forceJoinEnabled(): bool
    {
        return (bool) self::get('force_join_enabled', true);
    }
}
