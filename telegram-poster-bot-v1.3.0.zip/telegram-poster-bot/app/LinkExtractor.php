<?php
declare(strict_types=1);

final class LinkExtractor
{
    /**
     * Extract inline URLs (entity type url) and hyperlinks (text_link).
     * Also catches plain http(s)/t.me URLs if Telegram did not entity-tag them.
     *
     * @return list<array{url:string,label:string}>
     */
    public static function extract(array $msg): array
    {
        $text = tgText($msg);
        $entities = tgEntities($msg);
        $found = [];

        foreach ($entities as $ent) {
            $type = (string) ($ent['type'] ?? '');
            $off = (int) ($ent['offset'] ?? 0);
            $len = (int) ($ent['length'] ?? 0);
            $label = $len > 0 ? trim(utf16Slice($text, $off, $len)) : '';

            if ($type === 'text_link' && !empty($ent['url'])) {
                $url = trim((string) $ent['url']);
                $found[] = ['url' => $url, 'label' => $label !== '' ? $label : $url];
            } elseif ($type === 'url' && $label !== '') {
                $url = self::normalize($label);
                $found[] = ['url' => $url, 'label' => $label];
            } elseif ($type === 'text_mention' && !empty($ent['user']['username'])) {
                $url = 'https://t.me/' . $ent['user']['username'];
                $found[] = ['url' => $url, 'label' => $label !== '' ? $label : '@' . $ent['user']['username']];
            }
        }

        if (preg_match_all('~(?:https?://|www\.|t\.me/)[^\s<>\[\]()]+~iu', $text, $m)) {
            foreach ($m[0] as $raw) {
                $url = self::normalize($raw);
                $found[] = ['url' => $url, 'label' => rtrim($raw, '.,;')];
            }
        }

        $out = [];
        $seen = [];
        foreach ($found as $item) {
            $url = self::normalize($item['url']);
            if ($url === '' || !self::isValid($url)) {
                continue;
            }
            $key = mb_strtolower($url);
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $label = trim((string) $item['label']);
            if ($label === '' || self::isValid($label)) {
                $label = self::shortLabel($url);
            }
            $out[] = ['url' => $url, 'label' => mb_substr($label, 0, 80)];
        }
        return $out;
    }

    public static function normalize(string $url): string
    {
        $url = trim($url);
        $url = rtrim($url, '.,;)]}>»"\'');
        if ($url === '') {
            return '';
        }
        if (stripos($url, 'www.') === 0) {
            $url = 'https://' . $url;
        } elseif (stripos($url, 't.me/') === 0) {
            $url = 'https://' . $url;
        }
        return $url;
    }

    public static function isValid(string $url): bool
    {
        if (!preg_match('~^https?://~i', $url)) {
            return false;
        }
        return (bool) filter_var($url, FILTER_VALIDATE_URL);
    }

    private static function shortLabel(string $url): string
    {
        $host = (string) (parse_url($url, PHP_URL_HOST) ?? $url);
        return preg_replace('/^www\./i', '', $host) ?: $url;
    }
}
