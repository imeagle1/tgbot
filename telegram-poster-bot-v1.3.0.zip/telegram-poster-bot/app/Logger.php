<?php
declare(strict_types=1);

final class Logger
{
    public static function error(string $message): void
    {
        self::write('ERROR', $message);
    }

    public static function info(string $message): void
    {
        if (BOT_DEBUG) {
            self::write('INFO', $message);
        }
    }

    private static function write(string $level, string $message): void
    {
        $file = BOT_ROOT . '/storage/logs/bot-' . date('Y-m-d') . '.log';
        $line = '[' . date('Y-m-d H:i:s') . '][' . $level . '] ' . $message . PHP_EOL;
        @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
    }
}
