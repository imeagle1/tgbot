<?php
declare(strict_types=1);

final class PostService
{
    public static function createDraft(
        int $adminId,
        array $poster,
        string $caption,
        ?int $privateChatId,
        ?int $privateMid,
        bool $captionHtml = false,
        ?string $sourceUrl = null
    ): int {
        DB::exec(
            'INSERT INTO posts (status, poster_file_id, poster_unique_id, poster_type, caption_raw, private_chat_id, private_poster_mid, created_by, created_at, source_url, caption_html)
             VALUES (?,?,?,?,?,?,?,?,?,?,?)',
            [
                'collecting_links',
                $poster['file_id'],
                $poster['unique_id'] ?? '',
                $poster['type'] ?? 'photo',
                $caption,
                $privateChatId,
                $privateMid,
                $adminId,
                time(),
                $sourceUrl,
                $captionHtml ? 1 : 0,
            ]
        );
        return DB::lastId();
    }

    public static function get(int $id): ?array
    {
        return DB::one('SELECT * FROM posts WHERE id = ?', [$id]);
    }

    public static function addLinks(int $postId, array $links): int
    {
        $max = (int) (DB::col('SELECT MAX(sort_order) FROM post_links WHERE post_id = ?', [$postId]) ?? 0);
        $n = 0;
        $existing = DB::all('SELECT url FROM post_links WHERE post_id = ?', [$postId]);
        $have = [];
        foreach ($existing as $e) {
            $have[mb_strtolower((string) $e['url'])] = true;
        }
        foreach ($links as $link) {
            $url = (string) $link['url'];
            $key = mb_strtolower($url);
            if (isset($have[$key])) {
                continue;
            }
            $have[$key] = true;
            $max++;
            DB::exec(
                'INSERT INTO post_links (post_id, url, label, sort_order) VALUES (?,?,?,?)',
                [$postId, $url, $link['label'] ?? '', $max]
            );
            $n++;
        }
        return $n;
    }

    public static function addLinkMessage(int $postId, array $row): int
    {
        $max = (int) (DB::col('SELECT MAX(sort_order) FROM post_link_messages WHERE post_id = ?', [$postId]) ?? 0);
        DB::exec(
            'INSERT INTO post_link_messages (post_id, media_file_id, media_type, caption_html, private_chat_id, private_message_id, sort_order)
             VALUES (?,?,?,?,?,?,?)',
            [
                $postId,
                $row['media_file_id'] ?? null,
                $row['media_type'] ?? 'text',
                $row['caption_html'] ?? '',
                $row['private_chat_id'] ?? null,
                $row['private_message_id'] ?? null,
                $max + 1,
            ]
        );
        return DB::lastId();
    }

    public static function linkMessages(int $postId): array
    {
        return DB::all('SELECT * FROM post_link_messages WHERE post_id = ? ORDER BY sort_order ASC, id ASC', [$postId]);
    }

    public static function saveLinkMessageFromUpdate(Telegram $tg, int $postId, array $msg): array
    {
        $priv = Settings::privateChannelId();
        if (!$priv) {
            return ['ok' => false, 'error' => 'کانال خصوصی تنظیم نشده'];
        }
        $html = tgTextToHtml(tgText($msg), tgEntities($msg));
        $html = CaptionFilter::forLinkPost($html);
        $media = Media::poster($msg);
        $mediaFileId = null;
        $mediaType = 'text';
        $res = ['ok' => false];

        if ($media && ($media['type'] ?? '') === 'photo') {
            $mediaFileId = (string) $media['file_id'];
            $mediaType = 'photo';
            $res = $tg->sendPhoto((int) $priv, $mediaFileId, $html, ['parse_mode' => 'HTML']);
        } elseif ($media) {
            $mediaFileId = (string) $media['file_id'];
            $mediaType = 'document';
            $extra = ['parse_mode' => 'HTML'];
            if ($html !== '') {
                $extra['caption'] = $html;
            }
            $res = $tg->sendDocument((int) $priv, $mediaFileId, $extra);
        } else {
            $text = $html !== '' ? $html : '🔗 لینک‌ها';
            $res = $tg->sendMessage((int) $priv, $text, [
                'parse_mode' => 'HTML',
                'disable_web_page_preview' => false,
            ]);
        }

        if (empty($res['ok'])) {
            return ['ok' => false, 'error' => (string) ($res['description'] ?? 'ارسال به کانال خصوصی ناموفق بود')];
        }
        $mid = (int) $res['result']['message_id'];
        self::addLinkMessage($postId, [
            'media_file_id'      => $mediaFileId,
            'media_type'         => $mediaType,
            'caption_html'       => $html,
            'private_chat_id'    => $priv,
            'private_message_id' => $mid,
        ]);
        return ['ok' => true, 'message_id' => $mid];
    }

    public static function saveScrapedLinkPost(Telegram $tg, int $postId, array $movie, ?string $posterFileId = null): array
    {
        $priv = Settings::privateChannelId();
        if (!$priv) {
            return ['ok' => false, 'error' => 'کانال خصوصی تنظیم نشده'];
        }
        $html = CaptionFilter::forLinkPost(SiteScraper::linkCaption($movie));
        $photo = $posterFileId ?: (string) ($movie['poster'] ?? '');
        $res = ['ok' => false];
        $mediaFileId = $posterFileId;
        $mediaType = 'text';
        if ($photo !== '') {
            $res = $tg->sendPhoto((int) $priv, $photo, $html, ['parse_mode' => 'HTML']);
            if (!empty($res['ok'])) {
                $mediaType = 'photo';
                $photos = $res['result']['photo'] ?? [];
                if ($photos !== []) {
                    $last = $photos[count($photos) - 1];
                    $mediaFileId = (string) ($last['file_id'] ?? $posterFileId);
                }
            }
        }
        if (empty($res['ok'])) {
            $res = $tg->sendMessage((int) $priv, $html !== '' ? $html : '🔗 لینک‌ها', [
                'parse_mode' => 'HTML',
                'disable_web_page_preview' => false,
            ]);
            $mediaType = 'text';
        }
        if (empty($res['ok'])) {
            return ['ok' => false, 'error' => (string) ($res['description'] ?? 'ارسال پست لینک ناموفق بود')];
        }
        self::addLinkMessage($postId, [
            'media_file_id'      => $mediaFileId,
            'media_type'         => $mediaType,
            'caption_html'       => $html,
            'private_chat_id'    => $priv,
            'private_message_id' => (int) $res['result']['message_id'],
        ]);
        return ['ok' => true];
    }

    public static function appendCaption(int $postId, string $extra, bool $html = false): void
    {
        $post = self::get($postId);
        if (!$post) {
            return;
        }
        $cap = trim((string) ($post['caption_raw'] ?? ''));
        $extra = trim($extra);
        if ($extra === '') {
            return;
        }
        $makeHtml = $html || !empty($post['caption_html']);
        if ($makeHtml && empty($post['caption_html']) && $cap !== '') {
            $cap = h($cap);
        }
        $cap = $cap === '' ? $extra : ($cap . "\n\n" . $extra);
        DB::exec('UPDATE posts SET caption_raw = ?, caption_html = ? WHERE id = ?', [
            $cap,
            $makeHtml ? 1 : 0,
            $postId,
        ]);
    }

    public static function setSourceUrl(int $postId, string $url): void
    {
        DB::exec('UPDATE posts SET source_url = ? WHERE id = ?', [$url, $postId]);
    }

    public static function addFile(
        int $postId,
        array $file,
        string $quality,
        ?int $privChat,
        ?int $privMid,
        ?int $season = null,
        ?int $episode = null,
        ?string $qualityKey = null
    ): int {
        $max = (int) (DB::col('SELECT MAX(sort_order) FROM post_files WHERE post_id = ?', [$postId]) ?? 0);
        DB::exec(
            'INSERT INTO post_files (post_id, file_id, file_unique_id, file_type, quality, width, height, duration, file_size, mime, file_name, private_chat_id, private_message_id, sort_order, season, episode, quality_key)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
            [
                $postId,
                $file['file_id'],
                $file['unique_id'] ?? '',
                $file['type'] ?? 'video',
                $quality,
                $file['width'] ?? null,
                $file['height'] ?? null,
                $file['duration'] ?? null,
                $file['file_size'] ?? null,
                $file['mime'] ?? null,
                $file['file_name'] ?? null,
                $privChat,
                $privMid,
                $max + 1,
                $season,
                $episode,
                $qualityKey,
            ]
        );
        return DB::lastId();
    }

    public static function links(int $postId): array
    {
        return DB::all('SELECT * FROM post_links WHERE post_id = ? ORDER BY sort_order ASC, id ASC', [$postId]);
    }

    public static function files(int $postId): array
    {
        return DB::all('SELECT * FROM post_files WHERE post_id = ? ORDER BY sort_order ASC, id ASC', [$postId]);
    }

    public static function counts(int $postId): array
    {
        $linkMsgs = 0;
        try {
            $linkMsgs = (int) DB::col('SELECT COUNT(*) FROM post_link_messages WHERE post_id = ?', [$postId]);
        } catch (Throwable $e) {
            $linkMsgs = 0;
        }
        return [
            'links' => $linkMsgs + (int) DB::col('SELECT COUNT(*) FROM post_links WHERE post_id = ?', [$postId]),
            'files' => (int) DB::col('SELECT COUNT(*) FROM post_files WHERE post_id = ?', [$postId]),
        ];
    }

    public static function publish(Telegram $tg, int $postId): array
    {
        $post = self::get($postId);
        if (!$post) {
            return ['ok' => false, 'error' => 'پست پیدا نشد'];
        }
        $public = Settings::publicChannelId();
        if (!$public) {
            return ['ok' => false, 'error' => 'کانال عمومی تنظیم نشده'];
        }
        $counts = self::counts($postId);
        $isHtml = !empty($post['caption_html']);
        $caption = CaptionFilter::forPhoto((string) ($post['caption_raw'] ?? ''), $isHtml);
        $row = [];
        if ($counts['links'] > 0) {
            $row[] = urlBtn('لینک‌ها', $tg->botLink('l_' . $postId));
        }
        if ($counts['files'] > 0) {
            $row[] = urlBtn('فایل‌ها', $tg->botLink('f_' . $postId));
        }
        $extra = [];
        if ($row !== []) {
            $extra['reply_markup'] = kb([$row]);
        }
        if (!$isHtml) {
            $extra['parse_mode'] = '';
        }

        $fileId = (string) $post['poster_file_id'];
        if (($post['poster_type'] ?? 'photo') === 'photo') {
            $res = $tg->sendPhoto($public, $fileId, $caption, $extra);
        } else {
            $res = $tg->sendDocument($public, $fileId, array_merge($extra, [
                'caption' => $caption,
            ]));
        }
        if (empty($res['ok'])) {
            return ['ok' => false, 'error' => $res['description'] ?? 'ارسال به کانال عمومی ناموفق بود'];
        }
        $mid = (int) $res['result']['message_id'];
        DB::exec(
            'UPDATE posts SET status = ?, caption_public = ?, public_chat_id = ?, public_message_id = ?, published_at = ? WHERE id = ?',
            ['published', $caption, $public, $mid, time(), $postId]
        );
        return ['ok' => true, 'message_id' => $mid, 'counts' => $counts];
    }

    public static function archiveForward(Telegram $tg, array $msg): array
    {
        $priv = Settings::privateChannelId();
        if (!$priv) {
            return ['ok' => false];
        }
        $from = (int) $msg['chat']['id'];
        $mid = (int) $msg['message_id'];
        return $tg->forwardMessage($priv, $from, $mid);
    }

    public static function photoFromResult(array $res): ?array
    {
        if (empty($res['ok']) || empty($res['result']['photo']) || !is_array($res['result']['photo'])) {
            return null;
        }
        $photos = $res['result']['photo'];
        $p = $photos[count($photos) - 1];
        return [
            'type'      => 'photo',
            'file_id'   => (string) $p['file_id'],
            'unique_id' => (string) ($p['file_unique_id'] ?? ''),
            'width'     => (int) ($p['width'] ?? 0),
            'height'    => (int) ($p['height'] ?? 0),
            'file_size' => (int) ($p['file_size'] ?? 0),
            'file_name' => '',
            'mime'      => 'image/jpeg',
        ];
    }
}
