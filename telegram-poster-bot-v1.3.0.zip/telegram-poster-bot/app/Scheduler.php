<?php
declare(strict_types=1);

final class Scheduler
{
    public static function later(int $chatId, int $messageId, ?int $seconds = null): void
    {
        $seconds = $seconds ?? Settings::deleteAfter();
        $at = time() + max(5, $seconds);
        DB::exec(
            'INSERT INTO scheduled_deletes (chat_id, message_id, delete_at) VALUES (?,?,?)',
            [$chatId, $messageId, $at]
        );
    }

    public static function processDue(int $limit = 40): int
    {
        $now = time();
        $rows = DB::all(
            'SELECT id, chat_id, message_id FROM scheduled_deletes WHERE delete_at <= ? ORDER BY id ASC LIMIT ' . (int) $limit,
            [$now]
        );
        if ($rows === []) {
            return 0;
        }
        $tg = new Telegram();
        $n = 0;
        foreach ($rows as $row) {
            $tg->deleteMessage((int) $row['chat_id'], (int) $row['message_id']);
            DB::exec('DELETE FROM scheduled_deletes WHERE id = ?', [(int) $row['id']]);
            $n++;
        }
        return $n;
    }
}
