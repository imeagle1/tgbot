<?php
declare(strict_types=1);

final class QualityDetector
{
    public static function detect(array $file, string $caption = ''): string
    {
        $name = (string) ($file['file_name'] ?? '');
        $mime = (string) ($file['mime_type'] ?? '');
        $height = (int) ($file['height'] ?? 0);
        $hay = mb_strtolower($name . ' ' . $caption . ' ' . $mime);

        $res = self::resolution($hay, $height);
        $codec = self::codec($hay);
        $bit = preg_match('/10\s?bit|hi10/i', $hay) ? '10bit' : '';
        $src = self::source($hay);

        $parts = array_values(array_filter([$res, $codec, $bit, $src], static fn($x) => $x !== ''));
        if ($parts === []) {
            return $height > 0 ? ($height . 'p') : 'ویدیو';
        }
        return implode(' ', $parts);
    }

    private static function resolution(string $hay, int $height): string
    {
        if (preg_match('/(2160p|4k|uhd)/i', $hay)) {
            return '2160p';
        }
        if (preg_match('/(1440p|2k|qhd)/i', $hay)) {
            return '1440p';
        }
        if (preg_match('/(1080p|fhd|full\s?hd)/i', $hay)) {
            return '1080p';
        }
        if (preg_match('/(720p|(?<![a-z0-9])hd(?![a-z0-9]))/i', $hay)) {
            return '720p';
        }
        if (preg_match('/480p/i', $hay)) {
            return '480p';
        }
        if (preg_match('/360p/i', $hay)) {
            return '360p';
        }
        if (preg_match('/240p/i', $hay)) {
            return '240p';
        }
        if ($height >= 2100) {
            return '2160p';
        }
        if ($height >= 1400) {
            return '1440p';
        }
        if ($height >= 1000) {
            return '1080p';
        }
        if ($height >= 700) {
            return '720p';
        }
        if ($height >= 450) {
            return '480p';
        }
        if ($height >= 300) {
            return '360p';
        }
        if ($height > 0) {
            return $height . 'p';
        }
        return '';
    }

    private static function codec(string $hay): string
    {
        if (preg_match('/x265|hevc|h\.?265/i', $hay)) {
            return 'x265';
        }
        if (preg_match('/x264|avc|h\.?264/i', $hay)) {
            return 'x264';
        }
        if (preg_match('/av1/i', $hay)) {
            return 'AV1';
        }
        return '';
    }

    private static function source(string $hay): string
    {
        if (preg_match('/web-?dl/i', $hay)) {
            return 'WEB-DL';
        }
        if (preg_match('/webrip/i', $hay)) {
            return 'WEBRip';
        }
        if (preg_match('/blu-?ray|bluray|bdrip/i', $hay)) {
            return 'BluRay';
        }
        return '';
    }

    public static function buttonLabel(array $row): string
    {
        $q = trim((string) ($row['quality'] ?? 'ویدیو'));
        $size = bytesToHuman($row['file_size'] ?? 0);
        return $size !== '' ? "{$q} · {$size}" : $q;
    }

    public static function resolutionKey(array $file, string $quality = '', string $caption = ''): string
    {
        $name = (string) ($file['file_name'] ?? '');
        $height = (int) ($file['height'] ?? 0);
        $hay = mb_strtolower($name . ' ' . $caption . ' ' . $quality . ' ' . (string) ($file['mime'] ?? '') . ' ' . (string) ($file['mime_type'] ?? ''));
        $res = self::resolution($hay, $height);
        return $res !== '' ? $res : 'other';
    }
}
