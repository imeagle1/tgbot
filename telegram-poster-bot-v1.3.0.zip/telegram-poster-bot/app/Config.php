<?php
declare(strict_types=1);

final class Config
{
    public static function all(): array
    {
        return $GLOBALS['BOT_CONFIG'] ?? [];
    }

    public static function get(string $key, $default = null)
    {
        $cfg = self::all();
        if (array_key_exists($key, $cfg)) {
            return $cfg[$key];
        }
        if (strpos($key, '.') !== false) {
            $cur = $cfg;
            foreach (explode('.', $key) as $part) {
                if (!is_array($cur) || !array_key_exists($part, $cur)) {
                    return $default;
                }
                $cur = $cur[$part];
            }
            return $cur;
        }
        return $default;
    }
}
