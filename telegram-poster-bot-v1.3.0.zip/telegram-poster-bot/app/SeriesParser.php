<?php
declare(strict_types=1);

final class SeriesParser
{
    private const ORDINALS = [
        1 => 'اول', 2 => 'دوم', 3 => 'سوم', 4 => 'چهارم', 5 => 'پنجم',
        6 => 'ششم', 7 => 'هفتم', 8 => 'هشتم', 9 => 'نهم', 10 => 'دهم',
        11 => 'یازدهم', 12 => 'دوازدهم', 13 => 'سیزدهم', 14 => 'چهاردهم', 15 => 'پانزدهم',
        16 => 'شانزدهم', 17 => 'هفدهم', 18 => 'هجدهم', 19 => 'نوزدهم', 20 => 'بیستم',
    ];

    private const ORDINAL_WORDS = [
        'اول' => 1, 'دوم' => 2, 'سوم' => 3, 'چهارم' => 4, 'پنجم' => 5,
        'ششم' => 6, 'هفتم' => 7, 'هشتم' => 8, 'نهم' => 9, 'دهم' => 10,
        'یازدهم' => 11, 'دوازدهم' => 12, 'سیزدهم' => 13, 'چهاردهم' => 14, 'پانزدهم' => 15,
        'شانزدهم' => 16, 'هفدهم' => 17, 'هجدهم' => 18, 'نوزدهم' => 19, 'بیستم' => 20,
    ];

    private const QUALITY_RANK = [
        '2160p' => 1, '1440p' => 2, '1080p' => 3, '720p' => 4,
        '480p' => 5, '360p' => 6, '240p' => 7, 'other' => 90,
    ];

    /**
     * @return array{season:?int,episode:?int}
     */
    public static function parse(string $fileName, string $caption = ''): array
    {
        $hay = self::faToEn(trim($fileName . ' ' . $caption));
        if ($hay === '') {
            return ['season' => null, 'episode' => null];
        }

        $season = null;
        $episode = null;

        if (preg_match('/(?<![A-Za-z0-9])S(\d{1,2})[._\-\s]*E(\d{1,3})(?![A-Za-z0-9])/i', $hay, $m)) {
            $season = (int) $m[1];
            $episode = (int) $m[2];
        } elseif (preg_match('/(?<![A-Za-z0-9])(\d{1,2})x(\d{1,3})(?![A-Za-z0-9])/i', $hay, $m)) {
            $season = (int) $m[1];
            $episode = (int) $m[2];
        } else {
            if (preg_match('/فصل\s*(?:\.|:|-)?\s*(\d{1,2}|' . self::ordinalAlt() . ')/u', $hay, $m)) {
                $season = self::toInt($m[1]);
            } elseif (preg_match('/season\s*(\d{1,2})/i', $hay, $m)) {
                $season = (int) $m[1];
            }

            if (preg_match('/قسمت\s*(?:\.|:|-)?\s*(\d{1,3}|' . self::ordinalAlt() . ')/u', $hay, $m)) {
                $episode = self::toInt($m[1]);
            } elseif (preg_match('/(?:episode|ep)[\.\-_\s]*(\d{1,3})/i', $hay, $m)) {
                $episode = (int) $m[1];
            } elseif (preg_match('/(?<![A-Za-z0-9])E(\d{1,3})(?![A-Za-z0-9])/i', $hay, $m)) {
                $episode = (int) $m[1];
            }
        }

        if ($season !== null && ($season < 1 || $season > 50)) {
            $season = null;
        }
        if ($episode !== null && ($episode < 1 || $episode > 400)) {
            $episode = null;
        }
        if ($episode !== null && $season === null) {
            $season = 1;
        }

        return ['season' => $season, 'episode' => $episode];
    }

    public static function seasonLabel(int $season): string
    {
        if (isset(self::ORDINALS[$season])) {
            return 'فصل ' . self::ORDINALS[$season];
        }
        return 'فصل ' . $season;
    }

    public static function isSeriesFile(array $file): bool
    {
        $s = (int) ($file['season'] ?? 0);
        $e = (int) ($file['episode'] ?? 0);
        return $s > 0 || $e > 0;
    }

    public static function isSeries(array $files): bool
    {
        $n = 0;
        foreach ($files as $f) {
            if (self::isSeriesFile($f)) {
                $n++;
            }
        }
        return $n >= 2;
    }

    public static function fileSeason(array $file): int
    {
        $s = (int) ($file['season'] ?? 0);
        $e = (int) ($file['episode'] ?? 0);
        if ($s <= 0 && $e > 0) {
            return 1;
        }
        return $s;
    }

    /**
     * @param list<array<string,mixed>> $files
     * @return list<array{quality_key:string,season:int,label:string,files:list<array<string,mixed>>}>
     */
    public static function groups(array $files): array
    {
        $buckets = [];
        foreach ($files as $f) {
            if (!self::isSeriesFile($f)) {
                continue;
            }
            $q = trim((string) ($f['quality_key'] ?? ''));
            if ($q === '') {
                $q = 'other';
            }
            $s = self::fileSeason($f);
            if ($s <= 0) {
                $s = 1;
            }
            $key = $q . '|' . $s;
            if (!isset($buckets[$key])) {
                $buckets[$key] = [
                    'quality_key' => $q,
                    'season'      => $s,
                    'files'       => [],
                ];
            }
            $buckets[$key]['files'][] = $f;
        }

        foreach ($buckets as &$b) {
            usort($b['files'], static function (array $a, array $b): int {
                $ea = (int) ($a['episode'] ?? 0);
                $eb = (int) ($b['episode'] ?? 0);
                if ($ea !== $eb) {
                    return $ea <=> $eb;
                }
                return ((int) ($a['sort_order'] ?? 0)) <=> ((int) ($b['sort_order'] ?? 0));
            });
            $qShow = $b['quality_key'] === 'other' ? 'نامشخص' : $b['quality_key'];
            $b['label'] = 'کیفیت ' . $qShow . ' ' . self::seasonLabel((int) $b['season']);
        }
        unset($b);

        $list = array_values($buckets);
        usort($list, static function (array $a, array $b): int {
            $ra = self::QUALITY_RANK[$a['quality_key']] ?? 50;
            $rb = self::QUALITY_RANK[$b['quality_key']] ?? 50;
            if ($ra !== $rb) {
                return $ra <=> $rb;
            }
            if ($a['quality_key'] !== $b['quality_key']) {
                return strcmp($a['quality_key'], $b['quality_key']);
            }
            return $a['season'] <=> $b['season'];
        });
        return $list;
    }

    public static function buttonLabel(string $qualityKey, int $season): string
    {
        $qShow = $qualityKey === 'other' || $qualityKey === '' ? 'نامشخص' : $qualityKey;
        return 'کیفیت ' . $qShow . ' ' . self::seasonLabel($season);
    }

    private static function ordinalAlt(): string
    {
        return implode('|', array_map(static fn($w) => preg_quote($w, '/'), array_keys(self::ORDINAL_WORDS)));
    }

    private static function toInt(string $raw): int
    {
        $raw = trim($raw);
        if (isset(self::ORDINAL_WORDS[$raw])) {
            return self::ORDINAL_WORDS[$raw];
        }
        return (int) $raw;
    }

    private static function faToEn(string $s): string
    {
        return strtr($s, [
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ]);
    }
}
