<?php
declare(strict_types=1);

final class Media
{
    public static function poster(array $msg): ?array
    {
        if (!empty($msg['photo']) && is_array($msg['photo'])) {
            $p = $msg['photo'][count($msg['photo']) - 1];
            return [
                'type'      => 'photo',
                'file_id'   => (string) $p['file_id'],
                'unique_id' => (string) ($p['file_unique_id'] ?? ''),
                'width'     => (int) ($p['width'] ?? 0),
                'height'    => (int) ($p['height'] ?? 0),
                'file_size' => (int) ($p['file_size'] ?? 0),
                'file_name' => '',
                'mime'      => 'image/jpeg',
            ];
        }
        if (!empty($msg['document'])) {
            $d = $msg['document'];
            $mime = (string) ($d['mime_type'] ?? '');
            if (stripos($mime, 'image/') === 0) {
                return [
                    'type'      => 'document',
                    'file_id'   => (string) $d['file_id'],
                    'unique_id' => (string) ($d['file_unique_id'] ?? ''),
                    'width'     => (int) ($d['thumb']['width'] ?? 0),
                    'height'    => (int) ($d['thumb']['height'] ?? 0),
                    'file_size' => (int) ($d['file_size'] ?? 0),
                    'file_name' => (string) ($d['file_name'] ?? ''),
                    'mime'      => $mime,
                    'as'        => 'document',
                ];
            }
        }
        return null;
    }

    public static function video(array $msg): ?array
    {
        if (!empty($msg['video'])) {
            $v = $msg['video'];
            return [
                'type'      => 'video',
                'file_id'   => (string) $v['file_id'],
                'unique_id' => (string) ($v['file_unique_id'] ?? ''),
                'width'     => (int) ($v['width'] ?? 0),
                'height'    => (int) ($v['height'] ?? 0),
                'duration'  => (int) ($v['duration'] ?? 0),
                'file_size' => (int) ($v['file_size'] ?? 0),
                'file_name' => (string) ($v['file_name'] ?? ''),
                'mime'      => (string) ($v['mime_type'] ?? 'video/mp4'),
            ];
        }
        if (!empty($msg['document'])) {
            $d = $msg['document'];
            $name = (string) ($d['file_name'] ?? '');
            $mime = (string) ($d['mime_type'] ?? '');
            $isVid = stripos($mime, 'video/') === 0
                || preg_match('/\.(mkv|mp4|avi|mov|webm|ts|m4v|m2ts|mpg|mpeg)$/i', $name);
            if ($isVid) {
                return [
                    'type'      => 'document',
                    'file_id'   => (string) $d['file_id'],
                    'unique_id' => (string) ($d['file_unique_id'] ?? ''),
                    'width'     => (int) ($d['thumb']['width'] ?? 0),
                    'height'    => (int) ($d['thumb']['height'] ?? 0),
                    'duration'  => 0,
                    'file_size' => (int) ($d['file_size'] ?? 0),
                    'file_name' => $name,
                    'mime'      => $mime,
                ];
            }
        }
        return null;
    }

    public static function forwardedChannelId(array $msg): ?int
    {
        if (!empty($msg['forward_from_chat']['id'])) {
            $type = $msg['forward_from_chat']['type'] ?? '';
            if (in_array($type, ['channel', 'supergroup'], true)) {
                return (int) $msg['forward_from_chat']['id'];
            }
        }
        if (!empty($msg['forward_origin']['chat']['id'])) {
            return (int) $msg['forward_origin']['chat']['id'];
        }
        return null;
    }

    public static function forwardedChannelMeta(array $msg): ?array
    {
        $ch = $msg['forward_from_chat'] ?? ($msg['forward_origin']['chat'] ?? null);
        if (!is_array($ch) || empty($ch['id'])) {
            return null;
        }
        return [
            'id'       => (int) $ch['id'],
            'title'    => (string) ($ch['title'] ?? ''),
            'username' => (string) ($ch['username'] ?? ''),
            'type'     => (string) ($ch['type'] ?? 'channel'),
        ];
    }
}
