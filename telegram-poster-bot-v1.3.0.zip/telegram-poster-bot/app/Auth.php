<?php
declare(strict_types=1);

final class Auth
{
    public static function isAdmin(int $userId): bool
    {
        if ($userId === (int) Config::get('owner_id', 0)) {
            return true;
        }
        $row = DB::one('SELECT id FROM admins WHERE user_id = ?', [$userId]);
        return $row !== null;
    }

    public static function isOwner(int $userId): bool
    {
        if ($userId === (int) Config::get('owner_id', 0)) {
            return true;
        }
        $row = DB::one("SELECT id FROM admins WHERE user_id = ? AND role = 'owner'", [$userId]);
        return $row !== null;
    }

    public static function role(int $userId): string
    {
        if ($userId === (int) Config::get('owner_id', 0)) {
            return 'owner';
        }
        $row = DB::one('SELECT role FROM admins WHERE user_id = ?', [$userId]);
        return $row ? (string) $row['role'] : 'user';
    }

    public static function addAdmin(int $userId, ?string $username, string $role = 'admin'): void
    {
        $now = time();
        $exists = DB::one('SELECT id FROM admins WHERE user_id = ?', [$userId]);
        if ($exists) {
            DB::exec('UPDATE admins SET username = ?, role = ? WHERE user_id = ?', [$username, $role, $userId]);
            return;
        }
        DB::exec(
            'INSERT INTO admins (user_id, username, role, created_at) VALUES (?,?,?,?)',
            [$userId, $username, $role, $now]
        );
    }

    public static function removeAdmin(int $userId): bool
    {
        if ($userId === (int) Config::get('owner_id', 0)) {
            return false;
        }
        DB::exec('DELETE FROM admins WHERE user_id = ? AND role != ?', [$userId, 'owner']);
        return true;
    }

    public static function listAdmins(): array
    {
        return DB::all('SELECT * FROM admins ORDER BY role ASC, id ASC');
    }

    public static function state(int $userId): array
    {
        $row = DB::one('SELECT * FROM admin_states WHERE user_id = ?', [$userId]);
        if (!$row) {
            return ['state' => 'idle', 'post_id' => null, 'data' => []];
        }
        $data = json_decode((string) ($row['data'] ?? ''), true);
        return [
            'state'   => (string) $row['state'],
            'post_id' => $row['post_id'] ? (int) $row['post_id'] : null,
            'data'    => is_array($data) ? $data : [],
        ];
    }

    public static function setState(int $userId, string $state, ?int $postId = null, array $data = []): void
    {
        $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $now = time();
        if (DB::isSqlite()) {
            DB::exec(
                'INSERT INTO admin_states (user_id, state, post_id, data, updated_at) VALUES (?,?,?,?,?)
                 ON CONFLICT(user_id) DO UPDATE SET state = excluded.state, post_id = excluded.post_id, data = excluded.data, updated_at = excluded.updated_at',
                [$userId, $state, $postId, $json, $now]
            );
        } else {
            DB::exec(
                'INSERT INTO admin_states (user_id, state, post_id, data, updated_at) VALUES (?,?,?,?,?)
                 ON DUPLICATE KEY UPDATE state = VALUES(state), post_id = VALUES(post_id), data = VALUES(data), updated_at = VALUES(updated_at)',
                [$userId, $state, $postId, $json, $now]
            );
        }
    }

    public static function clearState(int $userId): void
    {
        self::setState($userId, 'idle', null, []);
    }
}
