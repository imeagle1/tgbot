<?php
declare(strict_types=1);

final class CaptionFilter
{
    public static function apply(string $text, bool $skipUrlFilters = false): string
    {
        $filters = DB::all('SELECT * FROM caption_filters WHERE is_active = 1 ORDER BY id ASC');
        foreach ($filters as $f) {
            $type = $f['type'] ?? 'plain';
            $pattern = (string) $f['pattern'];
            $rep = (string) ($f['replacement'] ?? '');
            if ($pattern === '') {
                continue;
            }
            if ($skipUrlFilters && $type === 'urls') {
                continue;
            }
            if ($type === 'regex') {
                $ok = @preg_match('/' . $pattern . '/u', '');
                if ($ok === false) {
                    Logger::error('bad filter regex #' . $f['id'] . ': ' . $pattern);
                    continue;
                }
                $text = (string) preg_replace('/' . $pattern . '/u', $rep, $text);
            } elseif ($type === 'username') {
                $text = (string) preg_replace('/(?:^|\s)@[A-Za-z0-9_]{4,32}\b/u', $rep === '' ? ' ' : $rep, $text);
            } elseif ($type === 'tmelink') {
                $text = (string) preg_replace('~(?:https?://)?(?:t\.me|telegram\.me)/[^\s]+~iu', $rep, $text);
            } elseif ($type === 'urls') {
                $text = (string) preg_replace('~https?://[^\s]+~iu', $rep, $text);
            } else {
                $text = str_ireplace($pattern, $rep, $text);
            }
        }
        $text = preg_replace("/[ \t]+/u", ' ', $text);
        $text = preg_replace("/\n{3,}/u", "\n\n", (string) $text);
        return trim((string) $text);
    }

    public static function applyHtml(string $html, bool $skipUrlFilters = true): string
    {
        $anchors = [];
        $i = 0;
        $protected = preg_replace_callback('~<a\b[^>]*>.*?</a>~isu', static function ($m) use (&$anchors, &$i) {
            $key = "\x01A{$i}A\x01";
            $anchors[$key] = $m[0];
            $i++;
            return $key;
        }, $html);
        if (!is_string($protected)) {
            $protected = $html;
        }
        $protected = self::apply($protected, $skipUrlFilters);
        foreach ($anchors as $key => $val) {
            $protected = str_replace($key, $val, $protected);
        }
        return $protected;
    }

    public static function withFooter(string $caption, bool $html = false): string
    {
        $footer = Settings::footer();
        $caption = trim($caption);
        if ($footer === '') {
            return $caption;
        }
        if ($html) {
            $footer = h($footer);
        }
        return $caption === '' ? $footer : ($caption . "\n\n" . $footer);
    }

    public static function forPhoto(string $caption, bool $isHtml = false): string
    {
        $caption = $isHtml ? self::applyHtml($caption) : self::apply($caption);
        $caption = self::withFooter($caption, $isHtml);
        if (mb_strlen($caption) > 1024) {
            $caption = mb_substr($caption, 0, 1021) . '…';
        }
        return $caption;
    }

    public static function forLinkPost(string $html): string
    {
        $html = self::applyHtml($html, true);
        if (mb_strlen($html) > 1024) {
            $html = mb_substr($html, 0, 1021) . '…';
        }
        return $html;
    }
}
