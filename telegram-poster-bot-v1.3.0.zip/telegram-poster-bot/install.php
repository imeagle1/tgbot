<?php
declare(strict_types=1);

define('BOT_ROOT', __DIR__);
define('BOT_VERSION', '1.3.0');

if (!function_exists('h')) {
    function h(?string $s): string
    {
        return htmlspecialchars((string) $s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
$lock = BOT_ROOT . '/storage/installed.lock';

header('Content-Type: text/html; charset=UTF-8');

if (is_file($lock) && !isset($_GET['reinstall'])) {
    http_response_code(403);
    echo '<!doctype html><meta charset="utf-8"><body dir="rtl" style="font-family:Tahoma;padding:40px">نصب قبلاً انجام شده. برای نصب مجدد فایل <code>storage/installed.lock</code> را حذف کنید.</body>';
    exit;
}

$errors = [];
$ok = [];
$phpOk = version_compare(PHP_VERSION, '8.0.0', '>=');
$ext = [
    'curl'     => extension_loaded('curl'),
    'json'     => extension_loaded('json'),
    'mbstring' => extension_loaded('mbstring'),
    'pdo'      => extension_loaded('pdo'),
    'pdo_mysql'=> extension_loaded('pdo_mysql'),
    'pdo_sqlite'=> extension_loaded('pdo_sqlite'),
];

function post(string $k, string $d = ''): string
{
    return trim((string) ($_POST[$k] ?? $d));
}

function writeConfig(array $cfg): void
{
    $export = var_export($cfg, true);
    $php = "<?php\ndeclare(strict_types=1);\n\nreturn {$export};\n";
    if (file_put_contents(BOT_ROOT . '/config.php', $php) === false) {
        throw new RuntimeException('نتوانستم config.php را بنویسم. دسترسی پوشه را روی ۷۵۵/۷۶۴ بگذارید.');
    }
}

$done = false;
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $token   = post('bot_token');
    $owner   = (int) post('owner_id');
    $whurl   = post('webhook_url');
    $driver  = post('driver') === 'sqlite' ? 'sqlite' : 'mysql';
    $tz      = post('timezone', 'Asia/Tehran');

    if ($token === '' || !preg_match('/^\d+:[A-Za-z0-9_-]+$/', $token)) {
        $errors[] = 'توکن ربات نامعتبر است.';
    }
    if ($owner <= 0) {
        $errors[] = 'آیدی عددی مالک را وارد کنید (از @userinfobot).';
    }
    if ($whurl === '' || !preg_match('~^https://~i', $whurl)) {
        $errors[] = 'آدرس وب‌هوک باید HTTPS باشد.';
    }
    if (!$phpOk) {
        $errors[] = 'PHP ۸ یا بالاتر لازم است.';
    }
    if (!$ext['curl'] || !$ext['json'] || !$ext['mbstring'] || !$ext['pdo']) {
        $errors[] = 'اکستنشن‌های curl، json، mbstring و pdo الزامی است.';
    }
    if ($driver === 'mysql' && !$ext['pdo_mysql']) {
        $errors[] = 'pdo_mysql فعال نیست.';
    }
    if ($driver === 'sqlite' && !$ext['pdo_sqlite']) {
        $errors[] = 'pdo_sqlite فعال نیست.';
    }

    $db = [
        'driver'  => $driver,
        'host'    => post('db_host', 'localhost'),
        'port'    => (int) post('db_port', '3306'),
        'name'    => post('db_name'),
        'user'    => post('db_user'),
        'pass'    => post('db_pass'),
        'charset' => 'utf8mb4',
        'sqlite'  => BOT_ROOT . '/storage/bot.sqlite',
    ];

    if ($errors === []) {
        $secret = bin2hex(random_bytes(24));
        $cron   = bin2hex(random_bytes(16));
        $cfg = [
            'bot_token'      => $token,
            'bot_username'   => '',
            'owner_id'       => $owner,
            'webhook_secret' => $secret,
            'cron_key'       => $cron,
            'webhook_url'    => $whurl,
            'db'             => $db,
            'timezone'       => $tz !== '' ? $tz : 'Asia/Tehran',
            'debug'          => false,
        ];

        try {
            writeConfig($cfg);
            $GLOBALS['BOT_CONFIG'] = $cfg;
            define('BOT_DEBUG', false);
            spl_autoload_register(static function (string $class): void {
                $file = BOT_ROOT . '/app/' . str_replace(['\\', '..'], ['/', ''], $class) . '.php';
                if (is_file($file)) {
                    require $file;
                }
            });
            require BOT_ROOT . '/app/Helpers.php';

            DB::init();
            DB::installSchema();

            Settings::set('delete_after', 30);
            Settings::set('force_join_enabled', true);
            Settings::set('footer', '');
            Auth::addAdmin($owner, null, 'owner');

            $tg = new Telegram();
            $me = $tg->getMe();
            if (empty($me['ok'])) {
                throw new RuntimeException('توکن تلگرام رد شد: ' . ($me['description'] ?? ''));
            }
            $username = (string) ($me['result']['username'] ?? '');
            Settings::set('bot_username', $username);

            $wh = $tg->setWebhook($whurl, $secret);
            if (empty($wh['ok'])) {
                throw new RuntimeException('setWebhook ناموفق: ' . ($wh['description'] ?? ''));
            }

            if (!is_dir(BOT_ROOT . '/storage/logs')) {
                mkdir(BOT_ROOT . '/storage/logs', 0755, true);
            }
            file_put_contents($lock, date('c'));
            $done = true;
            $ok[] = 'نصب کامل شد.';
            $ok[] = 'یوزرنیم ربات: @' . $username;
            $ok[] = 'کلید کرون: ' . $cron;
        } catch (Throwable $e) {
            $errors[] = $e->getMessage();
        }
    }
}

$autoWh = '';
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || ((int) ($_SERVER['SERVER_PORT'] ?? 0) === 443)
    || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
if (!empty($_SERVER['HTTP_HOST'])) {
    $scheme = $https ? 'https' : 'https';
    $autoWh = $scheme . '://' . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\') . '/webhook.php';
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>نصب ربات پوستر</title>
<style>
  :root { --bg:#0f1419; --card:#17202a; --line:#243140; --txt:#e8eef4; --mut:#8aa0b5; --acc:#3d9cf0; --ok:#3dd68c; --bad:#ff6b6b; }
  * { box-sizing:border-box; }
  body { margin:0; background:var(--bg); color:var(--txt); font-family: Tahoma, Vazirmatn, sans-serif; }
  .wrap { max-width:720px; margin:40px auto; padding:0 16px 60px; }
  h1 { font-size:22px; margin:0 0 8px; }
  p.sub { color:var(--mut); margin:0 0 24px; }
  .card { background:var(--card); border:1px solid var(--line); border-radius:14px; padding:22px; margin:14px 0; }
  label { display:block; margin:12px 0 6px; color:var(--mut); font-size:13px; }
  input, select { width:100%; padding:10px 12px; border-radius:8px; border:1px solid var(--line); background:#0f1720; color:var(--txt); font-size:14px; }
  button { background:var(--acc); color:#fff; border:0; padding:12px 18px; border-radius:10px; font-size:15px; cursor:pointer; margin-top:16px; width:100%; }
  .row { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
  .err { background:#3a1515; color:#ffd5d5; padding:10px 12px; border-radius:8px; margin:6px 0; }
  .ok { background:#103325; color:#c6f6d5; padding:10px 12px; border-radius:8px; margin:6px 0; }
  .chk { font-size:13px; color:var(--mut); }
  .chk b { color:var(--ok); }
  .chk span { color:var(--bad); }
  code { background:#0f1720; padding:1px 6px; border-radius:4px; }
  @media (max-width:640px){ .row{grid-template-columns:1fr;} }
</style>
</head>
<body>
<div class="wrap">
  <h1>نصب ربات پوستر و دانلودر</h1>
  <p class="sub">وب‌هوک PHP · سازگار با cPanel و هاست اشتراکی · نسخه <?= htmlspecialchars(defined('BOT_VERSION')?BOT_VERSION:'1.2.0') ?></p>

  <div class="card">
    <div class="chk">PHP: <?= $phpOk ? '<b>'.PHP_VERSION.'</b>' : '<span>'.PHP_VERSION.' (نیاز به ۸+)</span>' ?></div>
    <?php foreach ($ext as $n=>$v): ?>
      <div class="chk"><?= h($n) ?>: <?= $v ? '<b>OK</b>' : '<span>ندارد</span>' ?></div>
    <?php endforeach; ?>
  </div>

  <?php foreach ($errors as $e): ?><div class="err"><?= h($e) ?></div><?php endforeach; ?>
  <?php foreach ($ok as $e): ?><div class="ok"><?= h($e) ?></div><?php endforeach; ?>

  <?php if ($done): ?>
    <div class="card">
      <p>الان <code>install.php</code> را از هاست حذف کنید.</p>
      <p>کرون هر دقیقه:</p>
      <p><code>* * * * * php <?= h(BOT_ROOT) ?>/cron.php <?= h($cron ?? '') ?></code></p>
      <p>یا HTTP: <code><?= h($autoWh ? str_replace('webhook.php','cron.php',$autoWh).'?key='.($cron ?? '') : '') ?></code></p>
      <p>ربات را استارت کنید و از /panel کانال خصوصی و عمومی را تنظیم کنید.</p>
    </div>
  <?php else: ?>
  <form method="post" class="card" autocomplete="off">
    <label>توکن ربات</label>
    <input name="bot_token" required value="<?= h(post('bot_token')) ?>" placeholder="123456:AA...">

    <label>آیدی عددی مالک (Owner)</label>
    <input name="owner_id" required value="<?= h(post('owner_id')) ?>" placeholder="123456789">

    <label>آدرس وب‌هوک (HTTPS)</label>
    <input name="webhook_url" required value="<?= h(post('webhook_url', $autoWh)) ?>">

    <label>منطقه زمانی</label>
    <input name="timezone" value="<?= h(post('timezone', 'Asia/Tehran')) ?>">

    <label>دیتابیس</label>
    <select name="driver" id="driver">
      <option value="mysql" <?= post('driver','mysql')==='mysql'?'selected':'' ?>>MySQL / MariaDB (پیشنهادی)</option>
      <option value="sqlite" <?= post('driver')==='sqlite'?'selected':'' ?>>SQLite (بدون دیتابیس جدا)</option>
    </select>

    <div id="mysql-fields">
      <div class="row">
        <div><label>هاست</label><input name="db_host" value="<?= h(post('db_host','localhost')) ?>"></div>
        <div><label>پورت</label><input name="db_port" value="<?= h(post('db_port','3306')) ?>"></div>
      </div>
      <label>نام دیتابیس</label>
      <input name="db_name" value="<?= h(post('db_name')) ?>">
      <div class="row">
        <div><label>یوزر</label><input name="db_user" value="<?= h(post('db_user')) ?>"></div>
        <div><label>پسورد</label><input name="db_pass" type="password" value="<?= h(post('db_pass')) ?>"></div>
      </div>
    </div>
    <button type="submit">نصب و اتصال وب‌هوک</button>
  </form>
  <?php endif; ?>
</div>
<script>
  function tog(){ document.getElementById('mysql-fields').style.display = document.getElementById('driver').value==='sqlite' ? 'none':'block'; }
  document.getElementById('driver') && document.getElementById('driver').addEventListener('change', tog);
  tog();
</script>
</body>
</html>

