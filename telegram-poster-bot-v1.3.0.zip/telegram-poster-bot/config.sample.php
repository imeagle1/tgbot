<?php
/**
 * Copy this file to config.php and fill in the values,
 * or use install.php to generate it automatically.
 */
declare(strict_types=1);

return [
    'bot_token'       => '123456:ABC-REPLACE-ME',
    'bot_username'    => '',
    'owner_id'        => 0,
    'webhook_secret'  => 'change-me-long-random',
    'cron_key'        => 'change-me-cron-key',
    'webhook_url'     => 'https://example.com/telegram-poster-bot/webhook.php',

    'db' => [
        'driver'   => 'mysql', // mysql | sqlite
        'host'     => 'localhost',
        'port'     => 3306,
        'name'     => 'poster_bot',
        'user'     => 'db_user',
        'pass'     => 'db_pass',
        'charset'  => 'utf8mb4',
        'sqlite'   => __DIR__ . '/storage/bot.sqlite',
    ],

    'timezone' => 'Asia/Tehran',
    'debug'    => false,
];
