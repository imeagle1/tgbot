<?php
declare(strict_types=1);

/**
 * Run every minute:
 *   * * * * * php /home/USER/public_html/telegram-poster-bot/cron.php KEY >/dev/null 2>&1
 *
 * Or via HTTP:
 *   https://your-domain.com/telegram-poster-bot/cron.php?key=CRON_KEY
 *
 * The loop keeps running ~50 seconds so 30-second deletes stay accurate
 * without occupying a worker per user.
 */
require __DIR__ . '/bootstrap.php';

$key = (string) Config::get('cron_key', '');
$given = (string) ($_GET['key'] ?? ($argv[1] ?? ''));

if ($key === '' || !hash_equals($key, $given)) {
    http_response_code(401);
    header('Content-Type: text/plain; charset=UTF-8');
    exit('unauthorized');
}

@ignore_user_abort(true);
@set_time_limit(70);
header('Content-Type: text/plain; charset=UTF-8');

try {
    DB::init();
} catch (Throwable $e) {
    Logger::error('cron db: ' . $e->getMessage());
    exit('db error');
}

$end = time() + 50;
$deleted = 0;
while (time() < $end) {
    $deleted += Scheduler::processDue(80);
    sleep(4);
}

echo 'ok deleted=' . $deleted;
