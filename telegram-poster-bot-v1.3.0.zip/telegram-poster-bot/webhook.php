<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$secret = (string) Config::get('webhook_secret', '');
$given  = (string) ($_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? '');

if ($secret === '' || !hash_equals($secret, $given)) {
    http_response_code(401);
    header('Content-Type: text/plain; charset=UTF-8');
    exit('unauthorized');
}

header('Content-Type: text/plain; charset=UTF-8');
echo 'ok';

if (function_exists('fastcgi_finish_request')) {
    @fastcgi_finish_request();
} else {
    if (ob_get_level() > 0) {
        @ob_end_flush();
    }
    @flush();
}

$raw = file_get_contents('php://input');
if ($raw === false || $raw === '') {
    exit;
}

$update = json_decode($raw, true);
if (!is_array($update)) {
    Logger::error('Invalid update JSON');
    exit;
}

try {
    DB::init();
    Scheduler::processDue(40);
    (new PosterBot())->handle($update);
} catch (Throwable $e) {
    Logger::error($e->getMessage() . "\n" . $e->getTraceAsString());
}
